package com.ford.gpcse.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR46_SIGNOFF_MICRO_TYP")
public class SignoffMicroType {

    @EmbeddedId
    private SignoffMicroTypeId id;

    @ManyToOne
    @JoinColumn(name = "PCMR19_MICRO_TYP_C", referencedColumnName = "PCMR19_MICRO_TYP_C", insertable = false, updatable = false)
    private MicroType microType;  // Establish the foreign key relationship with MicroType

    @Column(name = "PCMR46_SIGNOFF_S")
    private LocalDateTime signoffS;

    @Column(name = "PCMR46_USER_CDSID_C", length = 8)
    private String userCdsidC;

    @Column(name = "PCMR46_REQT_Y")
    private LocalDateTime reqtY;

    @Column(name = "PCMR46_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR46_CREATE_S", nullable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR46_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR46_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;
}
