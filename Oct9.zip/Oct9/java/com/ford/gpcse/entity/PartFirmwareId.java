package com.ford.gpcse.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PartFirmwareId implements Serializable {

    private String part;
    private Long firmware;
}
