package com.ford.gpcse.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReplaceSblPartDetailsDto {
    private String moduleTypeCode;
    private Long microTypeCode;
    private String supplierCode;
    private Long newPartCheck;
}
