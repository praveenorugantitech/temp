package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.ExportFirwareXmlRequest;
import com.ford.gpcse.entity.*;
import com.ford.gpcse.repository.PartFirmwareRepository;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.repository.ProgramDescriptionRepository;
import com.ford.gpcse.service.FirmwareXmlExportV3Service;
import com.ford.gpcse.util.DateFormatterUtility;
import jakarta.persistence.criteria.*;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class FirmwareXmlExportV3ServiceImpl implements FirmwareXmlExportV3Service {
    private final PartRepository partRepository;
    private final ProgramDescriptionRepository programDescriptionRepository;
    private final PartFirmwareRepository partFirmwareRepository;

    @Override
    public Resource generateFirmwareV3Xml(ExportFirwareXmlRequest exportFirwareXmlRequest) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            // Create Document
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            // Disable external entity processing to prevent XXE attacks
            docFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            docFactory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            docFactory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            docFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
            docFactory.setExpandEntityReferences(false);

            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.newDocument();

            // Create root element
            Element rootElement = doc.createElement("ROOT");
            rootElement.setAttribute("Version", "3");
            rootElement.setAttribute("ExportedOn", DateFormatterUtility.formatExportedOn(LocalDateTime.now()));
            rootElement.setAttribute("ExportedBy", exportFirwareXmlRequest.getCreateUser());
            doc.appendChild(rootElement);

            Specification<Part> spec = buildSpecification(exportFirwareXmlRequest);
            List<Part> parts = partRepository.findAll(spec);

            for (Part part : parts) {
                Element pcmElement = doc.createElement("PCM");
                rootElement.appendChild(pcmElement);

                addChildElement(doc, pcmElement, "PartNumber", part.getPartR());
                addChildElement(doc, pcmElement, "ProgramDescription", part.getPartNumX());
                addChildElement(doc, pcmElement, "CatchWord", part.getCatchWordC());
                addChildElement(doc, pcmElement, "CalibrationNumber", part.getCalibR());
                addChildElement(doc, pcmElement, "MainStrategy", part.getStratRelC());
                addChildElement(doc, pcmElement, "ApprovedDate", DateFormatterUtility.dateTimeStringFormat(part.getReldY()));
                addChildElement(doc, pcmElement, "Production", "PROT".equals(part.getReleaseUsage().getRelUsgC()) ? "N" : "Y");
                addChildElement(doc, pcmElement, "ConcernNumber", part.getConcernC());
                addChildElement(doc, pcmElement, "ReleaseEngineer", part.getEngineerCdsidC());
                addChildElement(doc, pcmElement, "ModuleType", part.getHardwarePartR());
                addChildElement(doc, pcmElement, "ChipId", part.getChipD());
                addChildElement(doc, pcmElement, "WersNotice", DateFormatterUtility.formatWersNotice(part.getWersNtcR()));

                Specification<ProgramDescription> programDescriptionSpecification = findByPartR(part.getPartR());

                List<ProgramDescription> programDescriptions = programDescriptionRepository.findAll(programDescriptionSpecification);

                if (!programDescriptions.isEmpty()) {
                    for (ProgramDescription programDescription : programDescriptions) {
                        Element applicationElement = doc.createElement("Application");
                        rootElement.appendChild(applicationElement);

                        addChildElement(doc, applicationElement, "ID", String.valueOf(programDescription.getPgmK()));
                        addChildElement(doc, applicationElement, "ModelYear", String.valueOf(programDescription.getMdlYrR()));
                        addChildElement(doc, applicationElement, "Program", String.valueOf(programDescription.getPgmN()));
                        addChildElement(doc, applicationElement, "Platform", String.valueOf(programDescription.getPlatN()));
                        addChildElement(doc, applicationElement, "Engine", String.valueOf(programDescription.getEngN()));
                        addChildElement(doc, applicationElement, "Transmission", String.valueOf(programDescription.getTransN()));
                    }


                }

                Specification<PartFirmware> partFirmwareSpecification = findByPartRAndApproved(part.getPartR());
                List<PartFirmware> partFirmwares = partFirmwareRepository.findAll(partFirmwareSpecification);

                if (!partFirmwares.isEmpty()) {
                    for (PartFirmware partFirmware : partFirmwares) {
                        Element firmwareElement = doc.createElement("Firmware");
                        rootElement.appendChild(firmwareElement);

                        addChildElement(doc, firmwareElement, "ID", String.valueOf(partFirmware.getFirmware().getFirmwareK()));
                        addChildElement(doc, firmwareElement, "Description", partFirmware.getFirmware().getFirmwareN());
                        addChildElement(doc, firmwareElement, "Value", partFirmware.getFileN());
                        addChildElement(doc, firmwareElement, "ApprovedBy", partFirmware.getAprvdByCdsidC());
                        addChildElement(doc, firmwareElement, "ApprovedDate", DateFormatterUtility.dateTimeStringFormat(partFirmware.getAprvdY()));
                    }
                }
            }

            // Write custom XML declaration to the output stream
            String xmlDeclaration = "<?xml version=\"1.0\"?>";
            outputStream.write(xmlDeclaration.getBytes(StandardCharsets.UTF_8));

            // Set up the transformer
            TransformerFactory transformerFactory = TransformerFactory.newInstance();

            // Secure TransformerFactory: Disable access to external DTDs and entities
            transformerFactory.setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", "");
            transformerFactory.setAttribute("http://javax.xml.XMLConstants/property/accessExternalStylesheet", "");

            Transformer transformer = transformerFactory.newTransformer();

            // Configure transformer to omit XML declaration (since we wrote it manually)
            transformer.setOutputProperty("omit-xml-declaration", "yes");

            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(outputStream);
            transformer.transform(source, result);

            return new ByteArrayResource(outputStream.toByteArray());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private void addChildElement(Document doc, Element parent, String name, String value) {
        Element element = doc.createElement(name);
        element.appendChild(doc.createTextNode(value != null ? value : ""));
        parent.appendChild(element);
    }

    private Specification<PartFirmware> findByPartRAndApproved(String partR) {
        return (Root<PartFirmware> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) -> {
            // Create joins
            Join<PartFirmware, Firmware> firmwareJoin = root.join("firmware");
            Join<PartFirmware, Part> partJoin = root.join("part");

            // Define the predicates
            Predicate partRPredicate = criteriaBuilder.equal(partJoin.get("partR"), partR);
            Predicate approvedPredicate = criteriaBuilder.isNotNull(root.get("aprvdY"));

            // Combine the predicates
            assert query != null;
            query.where(criteriaBuilder.and(partRPredicate, approvedPredicate));

            // Add ordering
            query.orderBy(criteriaBuilder.asc(firmwareJoin.get("firmwareN")));

            // Selecting specific fields
            query.multiselect(firmwareJoin.get("firmwareK"), firmwareJoin.get("firmwareN"), root);

            return query.getRestriction();
        };
    }


    private Specification<ProgramDescription> findByPartR(String partR) {
        return (Root<ProgramDescription> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) -> {
            // Create a subquery for the ProgramPart entity
            assert query != null;
            Subquery<Long> subquery = query.subquery(Long.class);
            Root<ProgramPart> programPartRoot = subquery.from(ProgramPart.class);

            // Join to Part entity
            Join<ProgramPart, Part> programPartToPart = programPartRoot.join("part");

            // Subquery criteria
            subquery.select(programPartRoot.get("pgmK"))
                    .where(criteriaBuilder.equal(programPartToPart.get("partR"), partR));

            // Main query criteria
            return criteriaBuilder.in(root.get("pgmK")).value(subquery);
        };
    }

    private Specification<Part> buildSpecification(ExportFirwareXmlRequest request) {
        return (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            // Always include these base conditions
            predicates.add(criteriaBuilder.equal(root.get("archF"), "N"));
            predicates.add(criteriaBuilder.not(root.get("statC").in("NewPnRequest", "PeadEdit", "PeadComplete")));

            // Add conditions based on ExportFirwareXmlRequest
            if (request.getPartR() != null && !request.getPartR().isEmpty()) {
                predicates.add(root.get("partR").in(request.getPartR()));
            }

            if (request.getConcernC() != null && !request.getConcernC().isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("concernC"), request.getConcernC()));
            }

            if (request.getWersNtcR() != null && !request.getWersNtcR().isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("wersNtcR"), request.getWersNtcR()));
            }

            // Join with MicroType
            Join<Part, MicroType> microTypeJoin = root.join("microType", JoinType.LEFT);
            assert query != null;
            query.multiselect(
                    root.get("partR"),
                    root.get("partNumX"),
                    root.get("catchWordC"),
                    root.get("calibR"),
                    root.get("stratRelC"),
                    root.get("reldY"),
                    root.get("concernC"),
                    root.get("engineerCdsidC"),
                    root.get("hardwarePartR"),
                    root.get("chipD"),
                    root.get("wersNtcR"),
                    root.get("stratCalibPartR"),
                    microTypeJoin.get("microTypX"),
                    root.get("releaseUsage")
            );

            // Adding order
            query.orderBy(criteriaBuilder.asc(root.get("partR")));

            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }

}
