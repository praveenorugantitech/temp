package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.ExportFirwareXmlRequest;
import com.ford.gpcse.exception.InvalidInputException;
import com.ford.gpcse.service.ExportDataService;
import com.ford.gpcse.service.FirmwareXmlExportV3Service;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ExportDataServiceImpl implements ExportDataService {

    private final FirmwareXmlExportV3Service firmwareXmlExportV3Service;

    @Override
    public Resource fetchFirmareXml(ExportFirwareXmlRequest exportFirwareXmlRequest) {

        if ((exportFirwareXmlRequest.getConcernC() == null || exportFirwareXmlRequest.getConcernC().isEmpty()) && (exportFirwareXmlRequest.getPartR() == null || exportFirwareXmlRequest.getPartR().isEmpty()) && (exportFirwareXmlRequest.getWersNtcR() == null || exportFirwareXmlRequest.getWersNtcR().isEmpty())) {
            throw new InvalidInputException("<ROOT><ERROR>YOU MUST PROVIDE A WHERE CLAUSE.</ERROR></ROOT>");
        }
        if (exportFirwareXmlRequest.getExportVersion().equals("Version 3")) {
            return firmwareXmlExportV3Service.generateFirmwareV3Xml(exportFirwareXmlRequest);
        }
        return null;
    }


}
