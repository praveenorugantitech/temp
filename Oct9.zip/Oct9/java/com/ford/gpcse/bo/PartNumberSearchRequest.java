package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class PartNumberSearchRequest {

    private List<String> releaseTypes;
    private String moduleType;
    private String releaseUsage;
    private String assemblyPN;
    private String hardwarePN;
    private String softwarePN;
    private String appEng;
    private String catchWord;
    private String calibrationNum;
    private String mainStrategy;
    private String concernNumber;
    private String reldF;
    private String createdDateFrom;
    private String createdDateTo;
    private String releasedDateFrom;
    private String releasedDateTo;


}
