package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.ExportFirwareXmlRequest;
import com.ford.gpcse.exception.InvalidInputException;
import com.ford.gpcse.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ExportDataServiceImpl implements ExportDataService {

    private final FirmwareXmlExportV3Service firmwareXmlExportV3Service;
    private final FirmwareXmlExportV4Service firmwareXmlExportV4Service;
    private final FirmwareXmlExportV5Service firmwareXmlExportV5Service;
    private final FirmwareXmlExportV6Service firmwareXmlExportV6Service;
    private final FirmwareXmlExportV7Service firmwareXmlExportV7Service;

    @Override
    public Resource fetchFirmareXml(ExportFirwareXmlRequest exportFirwareXmlRequest) {

        if ((exportFirwareXmlRequest.getConcernC() == null || exportFirwareXmlRequest.getConcernC().isEmpty()) &&
                (exportFirwareXmlRequest.getPartR() == null || exportFirwareXmlRequest.getPartR().isEmpty()) && (exportFirwareXmlRequest.getWersNtcR() == null || exportFirwareXmlRequest.getWersNtcR().isEmpty())) {
            throw new InvalidInputException("<ROOT><ERROR>YOU MUST PROVIDE A WHERE CLAUSE.</ERROR></ROOT>");
        }

        return switch (exportFirwareXmlRequest.getExportVersion()) {
            case "Version 3" -> firmwareXmlExportV3Service.generateFirmwareV3Xml(exportFirwareXmlRequest);
            case "Version 4" -> firmwareXmlExportV4Service.generateFirmwareV4Xml(exportFirwareXmlRequest);
            case "Version 5" -> firmwareXmlExportV5Service.generateFirmwareV5Xml(exportFirwareXmlRequest);
            case "Version 6" -> firmwareXmlExportV6Service.generateFirmwareV6Xml(exportFirwareXmlRequest);
            case "Version 7" -> firmwareXmlExportV7Service.generateFirmwareV7Xml(exportFirwareXmlRequest);
            default -> null;
        };
    }
}
