package com.ford.gpcse.exception;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.bo.ErrorResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.time.LocalDateTime;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @LoggingAspect
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleResourceNotFoundException(ResourceNotFoundException ex, WebRequest request) {
        log.error("Resource not found: {}", ex.getMessage(), ex);
        return buildErrorResponse(ex.getMessage(), request, HttpStatus.NOT_FOUND);
    }

    @LoggingAspect
    @ExceptionHandler(InvalidInputException.class)
    public ResponseEntity<ErrorResponse> handleInvalidInputException(InvalidInputException ex, WebRequest request) {
        log.error("Invalid input: {}", ex.getMessage(), ex);
        return buildErrorResponse(ex.getMessage(), request, HttpStatus.BAD_REQUEST);
    }

    @LoggingAspect
    @ExceptionHandler({
            FirmwareAlreadyRequestedException.class,
            UnusedReleaseException.class,
            ResourceAlreadyExistException.class,
            InvalidPartNumberException.class,
            ProgramSearchLimitExceedException.class,
            UnableToUpdateException.class,
            MicroTypeAlreadyRequestedException.class,
            UnableToInsertException.class,
            UnableToSendEmailNotification.class
    })
    public ResponseEntity<ErrorResponse> handleConflictExceptions(Exception ex, WebRequest request) {
        log.error("Conflict error: {}", ex.getMessage(), ex);
        return buildErrorResponse(ex.getMessage(), request, HttpStatus.CONFLICT);
    }

    @LoggingAspect
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGlobalException(Exception ex, WebRequest request) {
        log.error("Internal server error: {}", ex.getMessage(), ex);
        return buildErrorResponse("Internal Server Error", request, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private ResponseEntity<ErrorResponse> buildErrorResponse(String message, WebRequest request, HttpStatus status) {
        // Create Details object
        ErrorResponse.Details details = new ErrorResponse.Details(
                request.getDescription(false),
                LocalDateTime.now()
        );

        // Create ErrorResponse object with status, message, and details
        ErrorResponse errorResponse = new ErrorResponse("error", message, details);

        return new ResponseEntity<>(errorResponse, status);
    }

}
