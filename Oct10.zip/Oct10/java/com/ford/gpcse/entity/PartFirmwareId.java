package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class PartFirmwareId implements Serializable {
    @Column(name = "PCMR01_PART_R", length = 24)
    private String partR;
    @Column(name = "PCMR03_FIRMWARE_K")
    private Long firmwareK;
}
