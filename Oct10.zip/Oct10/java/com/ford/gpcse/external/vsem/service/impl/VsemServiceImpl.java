package com.ford.gpcse.external.vsem.service.impl;

import com.ford.gpcse.config.AppConfig;
import com.ford.gpcse.external.vsem.service.AuthService;
import com.ford.gpcse.external.vsem.service.VsemService;
import com.ford.gpcse.model.VsemServiceResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

@Service
@RequiredArgsConstructor
public class VsemServiceImpl implements VsemService {
    private final AuthService authService;
    private final AppConfig appConfig;
    private final RestClient restClient;

    @Override
    public VsemServiceResponse fetchPartFilenames(String partNumber) {
        String accessToken = authService.fetchToken().getAccessToken();

        return restClient
                .get()
                .uri(appConfig.getVsemurl())
                .header("Authorization", "Bearer " + accessToken)
                .header("partNumber", partNumber)
                .retrieve()
                .toEntity(VsemServiceResponse.class).getBody();


    }
}
