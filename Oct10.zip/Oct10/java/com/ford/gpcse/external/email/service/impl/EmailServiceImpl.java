package com.ford.gpcse.external.email.service.impl;

import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.model.Email;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;


@Service
@RequiredArgsConstructor
@Slf4j
public class EmailServiceImpl implements EmailService {

    private final JavaMailSender emailSender;

    @Override
    public boolean sendMail(Email email) {
        try {
            MimeMessage message = emailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true); // true for multipart
            helper.setTo(email.getTo().toArray(String[]::new));
            helper.setSubject(email.getSubject());
            helper.setText(email.getBody(), true); // Set to true for HTML content
            helper.setFrom(email.getFrom());

            // emailSender.send(message); //TODO: SMTP Server not  available so commenting
            return true;
        } catch (MessagingException e) {
            log.error("Error occurred while sending email: {}", e.getMessage());
            return false;
        }
    }
}
