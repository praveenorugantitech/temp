package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class ProductionPartNumberSearchRequest {

    private String partNumber;
    private String wersNotice;
    private String catchWord;
    private String softwarePartNumber;
    private String calibrationNumber;
    private String stratRelName;
    private String chipId;


}
