package com.ford.gpcse.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class VsemServiceResponse {
    public String partstatus;
    private int status;
    private String message;
    private String partnumber;
    private List<String> partfilenames;
}
