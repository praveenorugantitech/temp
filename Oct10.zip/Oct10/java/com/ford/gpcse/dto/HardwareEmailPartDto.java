package com.ford.gpcse.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HardwareEmailPartDto {
    private String partR;
    private String engineerCdsidC;
    private String hardwarePartR;
    private String coreHardwarePartR;
    private String microTypX;
}
