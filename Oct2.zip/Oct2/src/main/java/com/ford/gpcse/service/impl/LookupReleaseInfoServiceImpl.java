package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.*;
import com.ford.gpcse.dto.FirmwareDto;
import com.ford.gpcse.dto.ReleaseStatusDto;
import com.ford.gpcse.entity.Part;
import com.ford.gpcse.entity.PgmReleaseRequest;
import com.ford.gpcse.entity.ProgramDescription;
import com.ford.gpcse.entity.ReleaseRequest;
import com.ford.gpcse.exception.ProgramSearchLimitExceedException;
import com.ford.gpcse.repository.PartFirmwareRepository;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.repository.ProgramDescriptionRepository;
import com.ford.gpcse.repository.ReleaseRequestRepository;
import com.ford.gpcse.service.LookupReleaseInfoService;
import com.ford.gpcse.util.DateFormatterUtility;
import com.ford.gpcse.util.NoticeFormatterUtility;
import jakarta.persistence.criteria.*;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class LookupReleaseInfoServiceImpl implements LookupReleaseInfoService {

    private final PartRepository partRepository;
    private final ReleaseRequestRepository releaseRequestRepository;
    private final PartFirmwareRepository partFirmwareRepository;
    private final ProgramDescriptionRepository programDescriptionRepository;

    @Override
    public List<FirmwareResponse> fetchFirmwareDetailsByWersConcern(String wersConcern) {
        return convertToFirmwareResponse(partRepository.fetchFirmwareDetailsByWersConcern(wersConcern));
    }

    @Override
    public List<FirmwareResponse> fetchFirmwareDetailsByWersNotice(String wersNotice) {
        return convertToFirmwareResponse(partRepository.findFirmwareDetailsByWersNotice(NoticeFormatterUtility.formatWersNotice(wersNotice)));
    }

    @Override
    public List<FirmwareResponse> fetchFirmwareDetailsByPrograms(List<Long> programKeys) {
        if (programKeys.size() >= 10) {
            throw new ProgramSearchLimitExceedException("Please select less than 10 programs.");
        }
        return convertToFirmwareResponse(partRepository.fetchFirmwareDetailsByPrograms(programKeys));
    }

    private List<FirmwareResponse> convertToFirmwareResponse(List<FirmwareDto> firmwareDtos) {
        return firmwareDtos.stream()
                .map(firmwareDto -> new FirmwareResponse(firmwareDto.getPartR(),
                        firmwareDto.getCalibPartR(),
                        firmwareDto.getCatchWordC(),
                        firmwareDto.getEngineerCdsidC(),
                        NoticeFormatterUtility.formatWersNotice(firmwareDto.getWersNtcR()),
                        firmwareDto.getRelUsgX(),
                        firmwareDto.getHardwarePartR(),
                        firmwareDto.getCoreHardwarePartR(),
                        firmwareDto.getMicroTypX(),
                        firmwareDto.getSuplX(),
                        firmwareDto.getCoreHardwareCdsidC(),
                        firmwareDto.getStratCalibPartR(),
                        firmwareDto.getStratRelC(),
                        firmwareDto.getChipD(),
                        firmwareDto.getPwrtrnCalibCdsidC(),
                        programDescriptionRepository.fetchProgramDescriptionByPartNumber(firmwareDto.getPartR()),
                        firmwareDto.getPartNumX(),
                        partFirmwareRepository.findPartFirmwareByPartNumber(firmwareDto.getPartR()),
                        firmwareDto.getRelTypX(),
                        firmwareDto.getConcernC(),
                        firmwareDto.getCmtX())).toList();
    }


    @Override
    public List<ReleaseStatusSearchResponse> fetchReleaseStatusDetails() {
        List<ReleaseStatusDto> releaseStatusDtos = partRepository.findReleaseStatusDetails();

        return releaseStatusDtos.stream()
                .map(releaseStatusDto ->
                        new ReleaseStatusSearchResponse(releaseStatusDto.getConcernC(),
                                releaseStatusDto.getPartR(),
                                releaseStatusDto.getRelTypX(),
                                releaseStatusDto.getStatC(),
                                DateFormatterUtility.formatDateMonthAbr(releaseStatusDto.getConcernY()))).toList();
    }

    @Override
    public List<PartNumberSearchResponse> fetchFirmwareDetailsByPartNumber(PartNumberSearchRequest partNumberSearchRequest) {
        // Create a specification based on the search request
        Specification<Part> spec = byCriteriaForPartNumber(partNumberSearchRequest);

        // Count total records matching the specification
        long totalRecords = partRepository.count(spec);

        // If total records exceed 498, throw an error
        if (totalRecords > 498) {
            throw new RuntimeException("Too many results. Please refine your search.");
        }

        // Fetch the results using the same specification
        List<Part> parts = partRepository.findAll(spec);

        // Map results to PartNumberSearchResponse
        return parts.stream().map(part ->
                        new PartNumberSearchResponse(part.getPartR(),
                                part.getHardwarePartR(),
                                part.getSupplier().getSuplX(),
                                part.getCatchWordC(),
                                part.getCalibR(),
                                part.getStatC(),
                                part.getConcernY()))
                .limit(498).toList(); // Limit to 498


    }

    @Override
    public List<ReleaseRequestResponse> fetchAllReleaseRequests() {
        List<ReleaseRequest> releaseRequests = releaseRequestRepository.findAll();
        return getReleaseRequestResponses(releaseRequests);
    }

    @Override
    public List<ReleaseRequestResponse> fetchReleaseRequests(ReleaseRequestSearchInput releaseRequestSearchInput) {
        Specification<ReleaseRequest> spec = findByCriteriaForReleaseRequests(releaseRequestSearchInput);
        List<ReleaseRequest> releaseRequests = releaseRequestRepository.findAll(spec);
        return getReleaseRequestResponses(releaseRequests);
    }


    private List<ReleaseRequestResponse> getReleaseRequestResponses(List<ReleaseRequest> releaseRequests) {
        List<ReleaseRequestResponse> releaseRequestResponses = new ArrayList<>();

        releaseRequests.forEach(releaseRequest ->
                releaseRequestResponses.add(ReleaseRequestResponse.builder()
                        .requestId(releaseRequest.getRelReqK())
                        .module(releaseRequest.getModuleType().getModuleTypC())
                        .rLevel(releaseRequest.getCalRLevelR())
                        .my(releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription().getMdlYrR())
                        .prog(releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription().getPgmN())
                        .engine(releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription().getEngN())
                        .status(releaseRequest.getStatusC())
                        .created(releaseRequest.getCreateS().format(DateTimeFormatter.ofPattern("MMM dd, yyyy")))
                        .owner(releaseRequest.getCreateUserC())
                        .build())
        );
        return releaseRequestResponses;
    }


    private Specification<Part> byCriteriaForPartNumber(PartNumberSearchRequest request) {
        return (Root<Part> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
            Predicate predicate = cb.conjunction();

            // Filter by PCMR01_ARCH_F
            predicate = cb.and(predicate, cb.equal(root.get("archF"), "N"));

            // Filter by PCMR01_STAT_C
            predicate = cb.and(predicate, cb.notEqual(root.get("statC"), "NewPnRequest"));


            // Filter by release types
            if (request.getReleaseTypes() != null && !request.getReleaseTypes().isEmpty()) {
                predicate = cb.and(predicate, root.get("releaseType").get("relTypX").in(request.getReleaseTypes()));
            }

            // Filter by module type
            if (request.getModuleType() != null) {
                predicate = cb.and(predicate, cb.equal(root.get("moduleType").get("moduleTypeCode"), request.getModuleType()));
            }

            // Filter by release usage
            if (request.getReleaseUsage() != null) {
                predicate = cb.and(predicate, cb.equal(root.get("releaseUsage").get("usageCode"), request.getReleaseUsage()));
            }

            // Filter by assembly part number
            if (request.getAssemblyPN() != null) {
                predicate = cb.and(predicate, cb.like(root.get("partNumX"), "%" + request.getAssemblyPN() + "%"));
            }

            // Filter by hardware part number
            if (request.getHardwarePN() != null) {
                predicate = cb.and(predicate, cb.like(root.get("hardwarePartR"), "%" + request.getHardwarePN() + "%"));
            }

            // Filter by software part number
            if (request.getSoftwarePN() != null) {
                predicate = cb.and(predicate, cb.like(root.get("swDlSpecR"), "%" + request.getSoftwarePN() + "%"));
            }

            // Filter by application engineer
            if (request.getAppEng() != null) {
                predicate = cb.and(predicate, cb.equal(root.get("engineerCdsidC"), request.getAppEng()));
            }

            // Filter by catch word
            if (request.getCatchWord() != null) {
                predicate = cb.and(predicate, cb.like(root.get("catchWordC"), "%" + request.getCatchWord() + "%"));
            }

            // Filter by calibration number
            if (request.getCalibrationNum() != null) {
                predicate = cb.and(predicate, cb.equal(root.get("calibR"), request.getCalibrationNum()));
            }

            // Filter by main strategy
            if (request.getMainStrategy() != null) {
                predicate = cb.and(predicate, cb.equal(root.get("stratRelC"), request.getMainStrategy()));
            }

            // Filter by concern number
            if (request.getConcernNumber() != null) {
                predicate = cb.and(predicate, cb.equal(root.get("concernC"), request.getConcernNumber()));
            }

            // Date filters
            if (request.getCreatedDateFrom() != null) {
                LocalDateTime createdDateFrom = LocalDateTime.of(LocalDate.parse(request.getCreatedDateFrom()), LocalDateTime.MIN.toLocalTime());
                predicate = cb.and(predicate, cb.greaterThanOrEqualTo(root.get("createS"), createdDateFrom));
            }
            if (request.getCreatedDateTo() != null) {
                LocalDateTime createdDateTo = LocalDateTime.of(LocalDate.parse(request.getCreatedDateTo()), LocalDateTime.MAX.toLocalTime());
                predicate = cb.and(predicate, cb.lessThanOrEqualTo(root.get("createS"), createdDateTo));
            }
            if (request.getReleasedDateFrom() != null) {
                predicate = cb.and(predicate, cb.greaterThanOrEqualTo(root.get("reldY"), LocalDate.parse(request.getReleasedDateFrom())));
            }
            if (request.getReleasedDateTo() != null) {
                predicate = cb.and(predicate, cb.lessThanOrEqualTo(root.get("reldY"), LocalDate.parse(request.getReleasedDateTo())));
            }

            // Set the order by concernC and partR
            assert query != null;
            query.orderBy(cb.asc(root.get("concernC")), cb.asc(root.get("partR")));

            return predicate;
        };
    }


    private Specification<ReleaseRequest> findByCriteriaForReleaseRequests(ReleaseRequestSearchInput releaseRequestSearchInput) {
        return (Root<ReleaseRequest> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) -> {
            Predicate predicate = criteriaBuilder.conjunction();

            int id = Integer.parseInt(releaseRequestSearchInput.getId());

            if (id != -1) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("relReqK"), id));
            }

            if (StringUtils.isNoneEmpty(releaseRequestSearchInput.getModuleTypeCode())) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(root.get("moduleType").get("moduleTypC"), "%" + releaseRequestSearchInput.getModuleTypeCode() + "%"));
            }

            if (StringUtils.isNoneEmpty(releaseRequestSearchInput.getCalibrationLevel())) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(root.get("calRLevelR"), "%" + releaseRequestSearchInput.getCalibrationLevel() + "%"));
            }

            if (StringUtils.isNoneEmpty(releaseRequestSearchInput.getStatus())) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(root.get("statusC"), "%" + releaseRequestSearchInput.getStatus() + "%"));
            }

            if (StringUtils.isNoneEmpty(releaseRequestSearchInput.getOwner())) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(root.get("createUserC"), "%" + releaseRequestSearchInput.getOwner() + "%"));
            }

            String modelYear = releaseRequestSearchInput.getModelYear();
            String program = releaseRequestSearchInput.getProgram();
            String engine = releaseRequestSearchInput.getEngine();

            // Subquery for WPCMS01_PGM_DESC based on modelYear, program, and engine
            if (!StringUtils.isBlank(modelYear) || !StringUtils.isBlank(program) || !StringUtils.isBlank(engine)) {
                // Create a subquery for the PGM_RELEASE_REQUEST table
                assert query != null;
                Subquery<Long> subquery = query.subquery(Long.class);
                Root<PgmReleaseRequest> subRoot = subquery.from(PgmReleaseRequest.class);
                subquery.select(subRoot.get("releaseRequest").get("relReqK"));

                // Join with ProgramDescription (WPCMS01_PGM_DESC)
                Join<PgmReleaseRequest, ProgramDescription> join = subRoot.join("programDescription");

                Predicate subPredicate = criteriaBuilder.conjunction();

                // Check for modelYear
                if (!StringUtils.isBlank(modelYear)) {
                    subPredicate = criteriaBuilder.and(subPredicate, criteriaBuilder.like(join.get("mdlYrR"), "%" + modelYear + "%"));
                }

                // Check for program
                if (!StringUtils.isBlank(program)) {
                    subPredicate = criteriaBuilder.and(subPredicate, criteriaBuilder.like(join.get("pgmN"), "%" + program + "%"));
                }

                // Check for engine
                if (!StringUtils.isBlank(engine)) {
                    subPredicate = criteriaBuilder.and(subPredicate, criteriaBuilder.like(join.get("engN"), "%" + engine + "%"));
                }

                subquery.where(subPredicate);
                predicate = criteriaBuilder.and(predicate, root.get("relReqK").in(subquery));
            }


            return predicate;
        };
    }
}