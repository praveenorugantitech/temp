package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.CreatePblRequest;
import com.ford.gpcse.bo.PartFirmwareRequest;
import com.ford.gpcse.bo.PartFirmwareResponse;
import com.ford.gpcse.bo.ReplacePblRequest;
import com.ford.gpcse.dto.HardwareEmailPartDto;
import com.ford.gpcse.dto.PartFirwareDto;
import com.ford.gpcse.exception.FirmwareAlreadyRequestedException;
import com.ford.gpcse.exception.ResourceNotFoundException;
import com.ford.gpcse.exception.UnableToInsertException;
import com.ford.gpcse.exception.UnusedReleaseException;
import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.model.Email;
import com.ford.gpcse.repository.FirmwareItemRepository;
import com.ford.gpcse.repository.PartFirmwareRepository;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.repository.ProgramDescriptionRepository;
import com.ford.gpcse.service.PblService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class PblServiceImpl implements PblService {

    private final FirmwareItemRepository firmwareItemRepository;
    private final PartFirmwareRepository partFirmwareRepository;
    private final PartRepository partRepository;
    private final EmailService emailService;
    private final ProgramDescriptionRepository programDescriptionRepository;

    @Transactional
    @Override
    public void createPbl(CreatePblRequest createPblRequest) {
        // Check if the firmware item already exists
        Long count = firmwareItemRepository.countByFirmwareItmX(createPblRequest.getNewPbl());

        if (count > 0) {
            throw new FirmwareAlreadyRequestedException(createPblRequest.getNewPbl());
        }

        int result = firmwareItemRepository.createPbl(createPblRequest.getNewPbl(), createPblRequest.getCreateUser(), createPblRequest.getLastUpdateUser(), createPblRequest.getModuleTypeCode());
        if (result == 0) {
            throw new UnableToInsertException("Error: Unable to insert " + createPblRequest.getNewPbl() + " firmware found for " + createPblRequest.getModuleTypeCode() + " module type.");
        }

        log.info("Part {} has been added to the firmware drop down list", createPblRequest.getNewPbl());
    }


    @Override
    public void replacePbl(ReplacePblRequest replacePblRequest) {

        // Check if the firmware item already exists
        Long count = firmwareItemRepository.countByFirmwareItmX(replacePblRequest.getNewPbl());

        if (count > 0) {
            throw new FirmwareAlreadyRequestedException(replacePblRequest.getNewPbl());
        }

        int result = firmwareItemRepository.createPbl(replacePblRequest.getNewPbl(), replacePblRequest.getCreateUser(), replacePblRequest.getLastUpdateUser(), replacePblRequest.getModuleTypeCode());
        if (result == 0) {
            throw new UnableToInsertException("Error: Unable to insert " + replacePblRequest.getNewPbl() + " firmware found for " + replacePblRequest.getModuleTypeCode() + " module type.");
        }

        sendHardwareEmail(replacePblRequest.getPartFirmwareRequests().stream().map(PartFirmwareRequest::getAssemblyPN).collect(Collectors.toList()));

        log.info("Part {} has been added to the firmware drop down list", replacePblRequest.getNewPbl());
    }


    private void sendHardwareEmail(List<String> partNumbers) {
        if (partNumbers == null || partNumbers.isEmpty()) {
            return;
        }

        // Query the database using the JPA repository
        List<HardwareEmailPartDto> results = partRepository.findPartsForEmail(partNumbers);

        if (results.isEmpty()) {
            return;
        }

        // Prepare email content
        String subject = "Revise hardware release. Replace PBL";
        StringBuilder emailBody = new StringBuilder();
        emailBody.append("<html><body><div>Please revise the following parts.</div><table border='1'>")
                .append("<tr><th>Assembly PN</th><th>Hardware PN</th><th>Core Hardware PN</th><th>Micro Type</th><th>D&R Eng</th></tr>");

        List<String> engineers = new ArrayList<>();

        for (HardwareEmailPartDto part : results) {
            String engineer = part.getEngineerCdsidC();
            if (!engineers.contains(engineer)) {
                engineers.add(engineer);
            }

            emailBody.append("<tr>")
                    .append("<td>").append(part.getPartR()).append("</td>")
                    .append("<td>").append(part.getHardwarePartR()).append("</td>")
                    .append("<td>").append(part.getCoreHardwarePartR()).append("</td>")
                    .append("<td>").append(part.getMicroTypX()).append("</td>")
                    .append("<td>").append(engineer).append("</td>")
                    .append("</tr>");
        }

        emailBody.append("</table></body></html>");

        // Send email
        emailService.sendMail(Email.builder().subject(subject).to(engineers).from("pcserel@ford.com").body(emailBody.toString()).build());
    }

    @Override
    public List<PartFirmwareResponse> findPartsByFirmware(ReplacePblRequest replacePblRequest) {
        // Check if the current pbl exists
        Long currentPblcount = partFirmwareRepository.countByfileN(replacePblRequest.getCurrentPbl());

        if (currentPblcount == 0) {
            throw new UnusedReleaseException(replacePblRequest.getCurrentPbl());
        }

        // Check if the new pbl exists
        Long newPblCount = firmwareItemRepository.countByFirmwareItmX(replacePblRequest.getNewPbl());

        if (newPblCount > 0) {
            throw new FirmwareAlreadyRequestedException(replacePblRequest.getNewPbl());
        }

        // fetch the PBL records

        List<PartFirwareDto> parts = partRepository.findPartsByFirmware(replacePblRequest.getNewPbl(), List.of("All"));

        if (parts.isEmpty()) {
            throw new ResourceNotFoundException("No Records were found.");
        }
        return convertToPartFirmwareResponse(parts);
    }

    private List<PartFirmwareResponse> convertToPartFirmwareResponse(List<PartFirwareDto> partFirmwareDtos) {
        return partFirmwareDtos.stream().map(partFirwareDto -> new PartFirmwareResponse(
                partFirwareDto.getPartR(),
                partFirwareDto.getEngineerCdsidC(),
                partFirwareDto.getHardwarePartR(),
                partFirwareDto.getCoreHardwarePartR(),
                partFirwareDto.getMicroTypX(),
                programDescriptionRepository.fetchProgramDescriptionByPartNumber(partFirwareDto.getPartR()),
                partFirwareDto.getPartNumX())).toList();
    }
}
