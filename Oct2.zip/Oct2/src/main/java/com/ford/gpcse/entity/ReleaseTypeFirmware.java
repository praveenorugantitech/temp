package com.ford.gpcse.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR23_REL_TYP_FIRMWARE")
public class ReleaseTypeFirmware {

    @EmbeddedId
    private ReleaseTypeFirmwareId id;

    // Defining foreign key relationships
    @ManyToOne
    @MapsId("relTyp")  // Maps relTyp in ReleaseTypeFirmwareId
    @JoinColumn(name = "PCMR15_REL_TYP_C", referencedColumnName = "PCMR15_REL_TYP_C")
    private ReleaseType releaseType;

    @ManyToOne
    @MapsId("firmwareKi")  // Maps firmwareKi in ReleaseTypeFirmwareId
    @JoinColumn(name = "PCMR03_FIRMWARE_K", referencedColumnName = "PCMR03_FIRMWARE_K")
    private Firmware firmware;

    @Column(name = "PCMR23_CREATE_USER_C", length = 8)
    private String createUser;

    @Column(name = "PCMR23_CREATE_S")
    private LocalDateTime createS;

    @Column(name = "PCMR23_LAST_UPDT_USER_C", length = 8)
    private String lastUpdtUserC;

    @Column(name = "PCMR23_LAST_UPDT_S")
    private LocalDateTime lastUpdtS;
}
