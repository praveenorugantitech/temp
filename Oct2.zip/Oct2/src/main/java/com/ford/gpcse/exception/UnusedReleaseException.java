package com.ford.gpcse.exception;

public class UnusedReleaseException extends RuntimeException {
    public UnusedReleaseException(String currentPbl) {
        super("Error: " + currentPbl + " has not been used in a release. Please use new PBL request.");
    }
}