package com.ford.gpcse.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR48_RELEASE_REQUEST")
public class ReleaseRequest {

    @Id
    @Column(name = "PCMR48_REL_REQ_K")
    private Long relReqK;

    @ManyToOne
    @JoinColumn(name = "PCMR14_MODULE_TYP_C", referencedColumnName = "PCMR14_MODULE_TYP_C")
    private ModuleType moduleType;

    @ManyToOne
    @JoinColumn(name = "PCMR24_REL_USG_C", referencedColumnName = "PCMR24_REL_USG_C")
    private RelUsg releaseUsage;

    @OneToMany(mappedBy = "releaseRequest")
    private List<PgmReleaseRequest> programReleaseRequests;

    @Column(name = "PCMR48_PRTY_C", length = 6)
    private String prtyC;

    @Column(name = "PCMR48_PRTY_DTL_X", length = 25)
    private String prtyDtlX;

    @Column(name = "PCMR48_REL_REQ_REASON_X", length = 200)
    private String relReqReasonX;

    @Column(name = "PCMR48_CAL_R_LEVEL_R", length = 10)
    private String calRLevelR;

    @Column(name = "PCMR48_COORD_REQ_F", nullable = false, length = 1)
    private String coordReqF;

    @Column(name = "PCMR48_STRAT_REL_C", length = 24)
    private String stratRelC;

    @Column(name = "PCMR48_STATUS_C", length = 30)
    private String statusC;

    @Column(name = "PCMR48_CONCERN_C", length = 10)
    private String concernC;

    @Column(name = "PCMR48_ALERT_C", length = 10)
    private String alertC;

    @Column(name = "PCMR48_BACK_COMPAT_F", nullable = false, length = 1)
    private String backCompatF;

    @Column(name = "PCMR48_BLD_LVL_C", length = 10)
    private String bldLvlC;

    @Column(name = "PCMR48_CAL_REL_Y")
    private LocalDate calRelY;

    @Column(name = "PCMR48_PROJECT_CONTROL_C", length = 8)
    private String projectControlC;

    @Column(name = "PCMR48_PREV_CONCERN_C", length = 10)
    private String prevConcernC;

    @Column(name = "PCMR48_RELEASE_TITLE_X", length = 100)
    private String releaseTitleX;

    @Column(name = "PCMR48_CAL_IN_CCM_F", nullable = false, length = 1)
    private String calInCcmF;

    @Column(name = "PCMR48_CAL_NUM_CCM_R", length = 10)
    private String calNumCcmR;

    @Column(name = "PCMR48_ADD_HW_SW_COORD_F", nullable = false, length = 1)
    private String addHwSwCoordF;

    @Column(name = "PCMR48_HW_SW_COORD_DETAIL_X", length = 100)
    private String hwSwCoordDetailX;

    @Column(name = "PCMR48_ALERT_REQUIRED_F", nullable = false, length = 1)
    private String alertRequiredF;

    @Column(name = "PCMR48_ALERT_DETAIL_X", length = 100)
    private String alertDetailX;

    @Column(name = "PCMR48_ROLL_PART_CHANGE_USAGE_F", nullable = false, length = 1)
    private String rollPartChangeUsageF;

    @Column(name = "PCMR48_ROLL_PART_CHANGE_USAGE_X", length = 100)
    private String rollPartChangeUsageX;

    @Column(name = "PCMR48_BUILD_START_Y")
    private LocalDate buildStartY;

    @Column(name = "PCMR48_SUPP_VBF_DEL_Y")
    private LocalDate suppVbfDelY;

    @Column(name = "PCMR48_APP_DR_ENG_C", length = 8)
    private String appDrEngC;

    @Column(name = "PCMR48_CAL_ENG_C", length = 8)
    private String calEngC;

    @Column(name = "PCMR48_CAL_REL_SUPPORT_C", length = 8)
    private String calRelSupportC;

    @Column(name = "PCMR48_HARDWARE_PART_R", length = 24)
    private String hardwarePartR;

    @Column(name = "PCMR48_IPF_INSTALLED_PART_R", length = 24)
    private String ipfInstalledPartR;

    @Column(name = "PCMR48_SERVICE_PART_R", length = 24)
    private String servicePartR;

    @Column(name = "PCMR48_CCM_FILE_NAME_N", length = 100)
    private String ccmFileNameN;

    @Column(name = "PCMR48_CCM_FILE_L")
    private byte[] ccmFileL;

    @Column(name = "PCMF48_CREATE_USER_C")
    private String createUserC;

    @NotNull
    @CreationTimestamp
    @Column(name = "PCMF48_CREATE_S", nullable = false, updatable = false)
    private LocalDateTime createS;

    @Column(name = "PCMF48_LAST_UPDT_USER_C")
    private String lastUpdtUserC;

    @NotNull
    @UpdateTimestamp
    @Column(name = "PCMF48_LAST_UPDT_S")
    private LocalDateTime lastUpdtS;


    @PrePersist
    public void prePersist() {
        this.coordReqF = "N";
        this.backCompatF = "N";
        this.calInCcmF = "N";
        this.addHwSwCoordF = "N";
        this.alertRequiredF = "N";
        this.rollPartChangeUsageF = "N";

    }


}
