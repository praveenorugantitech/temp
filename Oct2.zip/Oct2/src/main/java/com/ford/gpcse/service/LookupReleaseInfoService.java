package com.ford.gpcse.service;

import com.ford.gpcse.bo.*;
import com.ford.gpcse.dto.ProgramDescriptionDto;

import java.util.List;

public interface LookupReleaseInfoService {

    List<FirmwareResponse> fetchFirmwareDetailsByWersConcern(String wersConcern);

    List<FirmwareResponse> fetchFirmwareDetailsByWersNotice(String wersNotice);

    List<FirmwareResponse> fetchFirmwareDetailsByPrograms( List<Long> programKeys);

    List<ReleaseStatusSearchResponse> fetchReleaseStatusDetails();

    List<PartNumberSearchResponse> fetchFirmwareDetailsByPartNumber(PartNumberSearchRequest partNumberSearchRequest);

    List<ReleaseRequestResponse> fetchReleaseRequests(ReleaseRequestSearchInput releaseRequestSearchInput);

    List<ReleaseRequestResponse> fetchAllReleaseRequests();
}
