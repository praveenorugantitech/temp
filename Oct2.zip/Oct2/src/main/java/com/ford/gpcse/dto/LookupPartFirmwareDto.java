package com.ford.gpcse.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LookupPartFirmwareDto {
    private String firmwareN;
    private String fileN;
    private String aprvdByCdsidC;
    private String firmwareCatgN;
    private LocalDateTime aprvdY;
}
