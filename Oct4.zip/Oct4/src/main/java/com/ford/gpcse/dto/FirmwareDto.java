package com.ford.gpcse.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FirmwareDto {
    private String partR;
    private String partNumX;
    private String calibPartR;
    private String stratRelC;
    private String engineerCdsidC;
    private String hardwarePartR;
    private String microTypX;
    private String chipD;
    private String stratCalibPartR;
    private String catchWordC;
    private String relUsgX;
    private String relTypX;
    private String wersNtcR;
    private String concernC;
    private String cmtX;
    private String pwrtrnCalibCdsidC;
    private String suplX;
    private String coreHardwareCdsidC;
    private String coreHardwarePartR;
}