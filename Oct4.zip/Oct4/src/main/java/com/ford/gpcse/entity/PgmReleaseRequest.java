package com.ford.gpcse.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR49_PGM_RELEASE_REQUEST")
public class PgmReleaseRequest {
    @Id
    @Column(name = "PCMS01_PGM_K")
    private Long pgmK;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "PCMR48_REL_REQ_K", referencedColumnName = "PCMR48_REL_REQ_K", insertable = false, updatable = false)
    private ReleaseRequest releaseRequest;

    @ManyToOne
    @JoinColumn(name = "PCMS01_PGM_K", referencedColumnName = "PCMS01_PGM_K", insertable = false, updatable = false)
    private ProgramDescription programDescription;

    @Column(name = "PCMF49_CREATE_USER_C")
    private String createUserC;

    @NotNull
    @CreationTimestamp
    @Column(name = "PCMF49_CREATE_S", nullable = false, updatable = false)
    private LocalDateTime createS;

    @Column(name = "PCMF49_LAST_UPDT_USER_C")
    private String lastUpdtUserC;

    @NotNull
    @UpdateTimestamp
    @Column(name = "PCMF49_LAST_UPDT_S")
    private LocalDateTime lastUpdtS;


}
