package com.ford.gpcse.controller;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.MicroTypeView;
import com.ford.gpcse.bo.ModuleTypeView;
import com.ford.gpcse.bo.ReleaseRequestResponse;
import com.ford.gpcse.bo.SupplierView;
import com.ford.gpcse.dto.ProgramDescriptionDto;
import com.ford.gpcse.service.LookupDataService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1_0/lookup")
@Tag(description = "Lookup all the micro names, micro types, module names, module types, programs, suppliers and release requests.", name = "Lookup Data")
public class LookupDataController {

    private final LookupDataService lookupDataService;

    @GetMapping("/suppliers")
    @Operation(description = "Fetch All Active Suppliers", summary = "Fetch All Active Suppliers")
    @LoggingAspect
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<SupplierView> fetchActiveSuppliers() {
        return lookupDataService.fetchActiveSuppliers();
    }

    @GetMapping("/module-types")
    @Operation(description = "Fetch All Active Module Types", summary = "Fetch All Active Module Types")
    @LoggingAspect
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<ModuleTypeView> fetchActiveModuleTypes() {
        return lookupDataService.fetchActiveModuleTypes();
    }

    @GetMapping("/micro-types")
    @Operation(description = "Fetch All Micro Types", summary = "Fetch All Micro Types")
    @LoggingAspect
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<MicroTypeView> fetchReleasedMicroTypesByModuleType(@RequestParam String moduleTypeCode) {
        return lookupDataService.fetchReleasedMicroTypesByModuleType(moduleTypeCode);
    }

    @GetMapping("/micro-names")
    @Operation(description = "Fetch All Active Micro Names", summary = "Fetch All Active Micro Names")
    @LoggingAspect
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<String> fetchActiveMicroNames() {
        return lookupDataService.fetchActiveMicroNames();
    }

    @GetMapping("/module-names")
    @Operation(description = "Fetch All Active Module Names", summary = "Fetch All Active Module Names")
    @LoggingAspect
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<String> fetchActiveModuleNames() {
        return lookupDataService.fetchActiveModuleNames();
    }

    @GetMapping("/programs")
    @Operation(description = "Fetch Distinct Programs", summary = "Fetch Distinct Programs")
    @LoggingAspect
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<ProgramDescriptionDto> fetchDistinctPrograms() {
        return lookupDataService.fetchDistinctPrograms();
    }

    @LoggingAspect
    @TrackExecutionTime
    @PostMapping("/release-request")
    @Operation(description = "Fetch All Release Requests", summary = "Fetch All Release Requests")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully retrieved resource"), @ApiResponse(responseCode = "404", description = "Resource not found")})
    public List<ReleaseRequestResponse> fetchAllReleaseRequests() {
        return lookupDataService.fetchAllReleaseRequests();
    }
}
