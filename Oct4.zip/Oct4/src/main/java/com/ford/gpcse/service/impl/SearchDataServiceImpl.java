package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.*;
import com.ford.gpcse.dto.*;
import com.ford.gpcse.entity.Part;
import com.ford.gpcse.entity.PgmReleaseRequest;
import com.ford.gpcse.entity.ProgramDescription;
import com.ford.gpcse.entity.ReleaseRequest;
import com.ford.gpcse.exception.FirmwareAlreadyRequestedException;
import com.ford.gpcse.exception.ProgramSearchLimitExceedException;
import com.ford.gpcse.exception.ResourceNotFoundException;
import com.ford.gpcse.exception.UnusedReleaseException;
import com.ford.gpcse.repository.*;
import com.ford.gpcse.service.SearchDataService;
import com.ford.gpcse.util.DateFormatterUtility;
import com.ford.gpcse.util.NoticeFormatterUtility;
import jakarta.persistence.criteria.*;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class SearchDataServiceImpl implements SearchDataService {

    private final PartRepository partRepository;
    private final ReleaseRequestRepository releaseRequestRepository;
    private final PartFirmwareRepository partFirmwareRepository;
    private final ProgramDescriptionRepository programDescriptionRepository;
    private final FirmwareItemRepository firmwareItemRepository;
    private final FirmwareRepository firmwareRepository;

    @Override
    public List<FirmwareResponse> fetchFirmwareDetailsByWersConcern(String wersConcern) {
        return convertToFirmwareResponse(partRepository.fetchFirmwareDetailsByWersConcern(wersConcern));
    }

    @Override
    public List<FirmwareResponse> fetchFirmwareDetailsByWersNotice(String wersNotice) {
        return convertToFirmwareResponse(partRepository.findFirmwareDetailsByWersNotice(NoticeFormatterUtility.formatWersNotice(wersNotice)));
    }

    @Override
    public List<FirmwareResponse> fetchFirmwareDetailsByPrograms(List<Long> programKeys) {
        if (programKeys.size() >= 10) {
            throw new ProgramSearchLimitExceedException("Please select less than 10 programs.");
        }
        return convertToFirmwareResponse(partRepository.fetchFirmwareDetailsByPrograms(programKeys));
    }

    private List<FirmwareResponse> convertToFirmwareResponse(List<FirmwareDto> firmwareDtos) {
        return firmwareDtos.stream()
                .map(firmwareDto -> new FirmwareResponse(firmwareDto.getPartR(),
                        firmwareDto.getCalibPartR(),
                        firmwareDto.getCatchWordC(),
                        firmwareDto.getEngineerCdsidC(),
                        NoticeFormatterUtility.formatWersNotice(firmwareDto.getWersNtcR()),
                        firmwareDto.getRelUsgX(),
                        firmwareDto.getHardwarePartR(),
                        firmwareDto.getCoreHardwarePartR(),
                        firmwareDto.getMicroTypX(),
                        firmwareDto.getSuplX(),
                        firmwareDto.getCoreHardwareCdsidC(),
                        firmwareDto.getStratCalibPartR(),
                        firmwareDto.getStratRelC(),
                        firmwareDto.getChipD(),
                        firmwareDto.getPwrtrnCalibCdsidC(),
                        programDescriptionRepository.fetchProgramDescriptionByPartNumber(firmwareDto.getPartR()),
                        firmwareDto.getPartNumX(),
                        partFirmwareRepository.findPartFirmwareByPartNumber(firmwareDto.getPartR()),
                        firmwareDto.getRelTypX(),
                        firmwareDto.getConcernC(),
                        firmwareDto.getCmtX())).toList();
    }


    @Override
    public List<ReleaseStatusSearchResponse> fetchReleaseStatusDetails() {
        List<ReleaseStatusDto> releaseStatusDtos = partRepository.findReleaseStatusDetails();

        return releaseStatusDtos.stream()
                .map(releaseStatusDto ->
                        new ReleaseStatusSearchResponse(releaseStatusDto.getConcernC(),
                                releaseStatusDto.getPartR(),
                                releaseStatusDto.getRelTypX(),
                                releaseStatusDto.getStatC(),
                                DateFormatterUtility.formatDateMonthAbr(releaseStatusDto.getConcernY()))).toList();
    }

    @Override
    public List<PartNumberSearchResponse> fetchFirmwareDetailsByPartNumber(PartNumberSearchRequest partNumberSearchRequest) {
        // Create a specification based on the search request
        Specification<Part> spec = byCriteriaForPartNumber(partNumberSearchRequest);

        // Count total records matching the specification
        long totalRecords = partRepository.count(spec);

        // If total records exceed 498, throw an error
        if (totalRecords > 498) {
            throw new RuntimeException("Too many results. Please refine your search.");
        }

        // Fetch the results using the same specification
        List<Part> parts = partRepository.findAll(spec);

        // Map results to PartNumberSearchResponse
        return parts.stream().map(part ->
                        new PartNumberSearchResponse(part.getPartR(),
                                part.getHardwarePartR(),
                                part.getSupplier().getSuplX(),
                                part.getCatchWordC(),
                                part.getCalibR(),
                                part.getStatC(),
                                part.getConcernY(),
                                part.getReleaseType().getRelTypC(),
                                part.getReleaseUsage().getRelUsgC(),
                                part.getCmtX(),
                                part.getConcernC(),
                                part.getSwDlSpecR(),
                                part.getProcCmtX(),
                                part.getBldLvlC(),
                                part.getPrtyC(),
                                part.getPrtyDtlX()

                        ))
                .limit(498).toList(); // Limit to 498


    }


    @Override
    public List<PartFirmwareResponse> findPartsByFirmware(ReplacePblRequest replacePblRequest) {
        // Check if the current pbl exists
        Long currentPblcount = partFirmwareRepository.countByfileN(replacePblRequest.getCurrentPbl());

        if (currentPblcount == 0) {
            throw new UnusedReleaseException(replacePblRequest.getCurrentPbl());
        }

        // Check if the new pbl exists
        Long newPblCount = firmwareItemRepository.countByFirmwareItmX(replacePblRequest.getNewPbl());

        if (newPblCount > 0) {
            throw new FirmwareAlreadyRequestedException(replacePblRequest.getNewPbl());
        }

        // fetch the PBL records

        List<PartFirwareDto> parts = partRepository.findPartsByFirmware(replacePblRequest.getNewPbl(), List.of("All"));

        if (parts.isEmpty()) {
            throw new ResourceNotFoundException("No Records were found.");
        }
        return convertToPartFirmwareResponse(parts);
    }

    @Override
    public PrismDataInputResponse dataForPrismInputBasedOnPartNumber(String partNumber) {
        PrismDataInputDto prismDataInputDto = partRepository.dataForPrismInputBasedOnPartNumber(partNumber);
        return PrismDataInputResponse.builder()
                .calibPartNumber(prismDataInputDto.getStratCalibPartR())
                .part2PartNumber(firmwareRepository.fetchFileN(prismDataInputDto.getPartR(), "%Part II%"))
                .inputFile(prismDataInputDto.getStratRelC())
                .pdxPartNumber(firmwareRepository.fetchFileN(prismDataInputDto.getPartR(), "%PDX%"))
                .catchWord(prismDataInputDto.getCatchWordC())
                .chipId(prismDataInputDto.getChipD())
                .comments(prismDataInputDto.getWersNtcR())
                .engineSize(prismDataInputDto.getEngine())
                .hardwarePn(prismDataInputDto.getHardwarePartR())
                .modulePn(prismDataInputDto.getPartR())
                .vehicleAppl(prismDataInputDto.getVehicleLine())
                .vehicleCal(prismDataInputDto.getCalibR())
                .wersNotice(prismDataInputDto.getWersNtcR())
                .build();
    }

    @Override
    public String fetchWersTextByConcern(String wersConcern) {
        // Fetch Part Numbers based on Wers Concern
        List<String> partNumbers = partRepository.fetchPartNumbersBasedOnConcern(wersConcern);

        if (partNumbers.isEmpty()) {
            return "No Parts to display";
        }


        List<WersTextPartDto> wersTextPartDtos = partRepository.findPartsWithPrograms(partNumbers);
        List<WersTextPartDescriptionDto> wersTextPartDescriptionDtos = programDescriptionRepository.findPartsWithProgramDescription(partNumbers);
        List<WersTextPartCalibDto> wersTextPartCalibDtos = partRepository.findPartsWithCalib(partNumbers);

        StringBuilder strText = new StringBuilder();

        for (WersTextPartDto partDto : wersTextPartDtos) {
            // Append programs
            String programs = partDto.getPrograms();
            if (programs != null && !programs.isEmpty()) {
                strText.append(programs).append("<br>");
            }

            // Build display values
            strText.append(wordWrap(getDisplayValue(partDto.getRelTypeC()) + " - " + getDisplayValue(partDto.getReleaseUsageC()), 79, " ", "<br>")).append("<br>");
            strText.append(wordWrap(getDisplayValue(partDto.getBackwardCompatC()), 79, " ", "<br>")).append("<br>");
            strText.append("HARDWARE: ").append(partDto.getHardwarePartR()).append("<br>");
            strText.append("RELATED MODULES:<br>");

            // Call to create table from descriptions
            strText.append(wersTable(wersTextPartDescriptionDtos, partDto.getRelTypeC())).append("<br>");
        }

        // Add lineage table
        strText.append(generateLineageTable(wersTextPartCalibDtos)).append("<br>");

        return strText.toString();
    }


    private String wersTable(List<WersTextPartDescriptionDto> descriptions, String relTypeCode) {
        StringBuilder strHtm = new StringBuilder();
        List<String[]> tableRows = new ArrayList<>();

        for (WersTextPartDescriptionDto desc : descriptions) {
            // Create an array for each row
            tableRows.add(new String[]{String.valueOf(desc.getPgmK()), desc.getMdlYrR(), desc.getPgmN(), desc.getPlatN(), desc.getEngN(), desc.getTransN()});
        }

        // Process table rows
        for (String[] row : tableRows) {
            for (String cell : row) {
                strHtm.append(cell).append("  ");
            }
            strHtm.setLength(strHtm.length() - 2); // Remove last two spaces
            strHtm.append("<br>");
        }

        return strHtm.toString();
    }

    private String generateLineageTable(List<WersTextPartCalibDto> parts) {
        StringBuilder strHtm = new StringBuilder();
        String[][] aryTable = new String[parts.size() + 1][7];

        // Set header
        aryTable[0][0] = "LINEAGE";
        aryTable[0][1] = "OLD CAL";
        aryTable[0][2] = "OLD PN---";
        aryTable[0][3] = "OLD CW";
        aryTable[0][4] = "NEW CAL";
        aryTable[0][5] = "NEW PN---";
        aryTable[0][6] = "NEW CW";

        for (int i = 0; i < parts.size(); i++) {
            WersTextPartCalibDto part = parts.get(i);
            aryTable[i + 1][0] = part.getPartNumX();

            aryTable[i + 1][1] = (part.getOldCal() == null || part.getOldCal().isEmpty()) ? "N/A" : part.getOldCal();
            aryTable[i + 1][2] = (part.getReplacedPartR() == null || part.getReplacedPartR().isEmpty()) ? "N/A" : part.getReplacedPartR();
            aryTable[i + 1][3] = (part.getOldCw() == null || part.getOldCw().isEmpty()) ? "N/A" : part.getOldCw();
            aryTable[i + 1][4] = (part.getCalibR() == null || part.getCalibR().isEmpty()) ? "N/A" : part.getCalibR();

            if ("NewPnRequest".equals(part.getStatC())) {
                aryTable[i + 1][5] = "TBD";
                aryTable[i + 1][6] = "TBD";
            } else {
                aryTable[i + 1][5] = part.getPartR();
                aryTable[i + 1][6] = part.getCatchwordC();
            }
        }

        // Generate HTML for lineage table
        for (String[] row : aryTable) {
            for (String cell : row) {
                strHtm.append(cell).append("  ");
            }
            strHtm.setLength(strHtm.length() - 2); // Remove last two spaces
            strHtm.append("<br>");
        }

        return strHtm.toString();
    }

    private String getDisplayValue(String code) {
        // Mocked method; replace with actual logic to fetch display values based on code
        return code != null ? code : "Unknown";
    }

    private String wordWrap(String text, int width, String breakChars, String lineBreak) {
        String[] words = text.split(" ");
        StringBuilder wrappedText = new StringBuilder();
        StringBuilder line = new StringBuilder();

        for (String word : words) {
            if (line.length() + word.length() > width) {
                wrappedText.append(line).append(lineBreak);
                line.setLength(0); // Reset line
            }
            line.append(word).append(" ");
        }
        wrappedText.append(line); // Append remaining words

        return wrappedText.toString().trim();
    }

    @Override
    public List<FindProductionPartNumberResponse> findProductionPartNumber(FindProductionPartNumberRequest findProductionPartNumberRequest) {
        List<Part> parts = partRepository.findAll(buildfindProductionPartNumberSpecification(findProductionPartNumberRequest));

        List<FindProductionPartNumberResponse> findProductionPartNumberResponses = new ArrayList<>();

        parts.forEach(
                part -> findProductionPartNumberResponses.add(FindProductionPartNumberResponse.builder()
                        .partNumber(part.getPartR())
                        .calibrationNumber(part.getCalibR())
                        .softwarePN(part.getStratCalibPartR())
                        .wersNotice(part.getWersNtcR())
                        .mainMicroType(part.getMicroType().getMicroTypX())
                        .catchWord(part.getCatchWordC())
                        .hardwarePN(part.getHardwarePartR())
                        .build())
        );

        return findProductionPartNumberResponses;
    }

    private List<PartFirmwareResponse> convertToPartFirmwareResponse(List<PartFirwareDto> partFirmwareDtos) {
        return partFirmwareDtos.stream().map(partFirwareDto -> new PartFirmwareResponse(
                partFirwareDto.getPartR(),
                partFirwareDto.getEngineerCdsidC(),
                partFirwareDto.getHardwarePartR(),
                partFirwareDto.getCoreHardwarePartR(),
                partFirwareDto.getMicroTypX(),
                programDescriptionRepository.fetchProgramDescriptionByPartNumber(partFirwareDto.getPartR()),
                partFirwareDto.getPartNumX())).toList();
    }


    private Specification<Part> buildfindProductionPartNumberSpecification(FindProductionPartNumberRequest findProductionPartNumberRequest) {
        return (root, query, cb) -> {
            Predicate predicate = cb.conjunction();

            // Filter by Part Number
            if (findProductionPartNumberRequest.getPartNumber() != null && !findProductionPartNumberRequest.getPartNumber().isEmpty()) {
                String partNum = findProductionPartNumberRequest.getPartNumber().toUpperCase();
                predicate = cb.and(predicate, cb.like(cb.upper(root.get("partR")), "%" + partNum + "%"));
            }

            // Filter by Software Part Number
            if (findProductionPartNumberRequest.getSoftwarePartNumber() != null && !findProductionPartNumberRequest.getSoftwarePartNumber().isEmpty()) {
                String swPartNum = findProductionPartNumberRequest.getSoftwarePartNumber().toUpperCase();
                predicate = cb.and(predicate, cb.like(cb.upper(root.get("stratCalibPartR")), "%" + swPartNum + "%"));
            }

            // Filter by Catchword
            if (findProductionPartNumberRequest.getCatchWord() != null && !findProductionPartNumberRequest.getCatchWord().isEmpty()) {
                String catchWord = findProductionPartNumberRequest.getCatchWord().toUpperCase();
                predicate = cb.and(predicate, cb.like(cb.upper(root.get("catchWordC")), "%" + catchWord + "%"));
            }

            // Filter by Calibration Number
            if (findProductionPartNumberRequest.getCalibrationNumber() != null && !findProductionPartNumberRequest.getCalibrationNumber().isEmpty()) {
                String calibrationNum = findProductionPartNumberRequest.getCalibrationNumber().toUpperCase();
                predicate = cb.and(predicate, cb.like(cb.upper(root.get("calibR")), "%" + calibrationNum + "%"));
            }

            // Filter by Notice Number
            if (findProductionPartNumberRequest.getWersNotice() != null && !findProductionPartNumberRequest.getWersNotice().isEmpty()) {
                String noticeNumber = findProductionPartNumberRequest.getWersNotice().toUpperCase();
                predicate = cb.and(predicate, cb.like(cb.upper(root.get("wersNtcR")), "%" + noticeNumber + "%"));
            }

            // Filter by Maintenance Strategy
            if (findProductionPartNumberRequest.getStratRelName() != null && !findProductionPartNumberRequest.getStratRelName().isEmpty()) {
                String stratRelName = findProductionPartNumberRequest.getStratRelName().toUpperCase();
                predicate = cb.and(predicate, cb.like(cb.upper(root.get("stratRelC")), "%" + stratRelName + "%"));
            }

            // Filter by Chip ID
            if (findProductionPartNumberRequest.getChipId() != null && !findProductionPartNumberRequest.getChipId().isEmpty()) {
                String chipID = findProductionPartNumberRequest.getChipId().toUpperCase();
                predicate = cb.and(predicate, cb.like(cb.upper(root.get("chipD")), "%" + chipID + "%"));
            }

            // Additional static filters
            predicate = cb.and(predicate,
                    cb.equal(root.get("archF"), "N"),
                    cb.isNotNull(root.get("moduleType")),
                    cb.isNotNull(root.get("releaseType"))
            );


            return predicate;
        };
    }

    @Override
    public List<ReleaseRequestResponse> fetchReleaseRequests(ReleaseRequestSearchInput releaseRequestSearchInput) {
        Specification<ReleaseRequest> spec = findByCriteriaForReleaseRequests(releaseRequestSearchInput);
        List<ReleaseRequest> releaseRequests = releaseRequestRepository.findAll(spec);
        List<ReleaseRequestResponse> releaseRequestResponses = new ArrayList<>();

        releaseRequests.forEach(releaseRequest ->
                releaseRequestResponses.add(ReleaseRequestResponse.builder()
                        .requestId(releaseRequest.getRelReqK())
                        .module(releaseRequest.getModuleType().getModuleTypC())
                        .rLevel(releaseRequest.getCalRLevelR())
                        .my(releaseRequest.getProgramReleaseRequests() != null && !releaseRequest.getProgramReleaseRequests().isEmpty() ? releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription().getMdlYrR() : null)
                        .prog(releaseRequest.getProgramReleaseRequests() != null && !releaseRequest.getProgramReleaseRequests().isEmpty() ? releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription().getPgmN() : null)
                        .engine(releaseRequest.getProgramReleaseRequests() != null && !releaseRequest.getProgramReleaseRequests().isEmpty() ? releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription().getEngN() : null)
                        .status(releaseRequest.getStatusC())
                        .created(releaseRequest.getCreateS().format(DateTimeFormatter.ofPattern("MMM dd, yyyy")))
                        .owner(releaseRequest.getCreateUserC())
                        .build())
        );

        return releaseRequestResponses;
    }


    private Specification<Part> byCriteriaForPartNumber(PartNumberSearchRequest request) {
        return (Root<Part> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {
            Predicate predicate = cb.conjunction();

            // Filter by PCMR01_ARCH_F
            predicate = cb.and(predicate, cb.equal(root.get("archF"), "N"));

            // Filter by PCMR01_STAT_C
            predicate = cb.and(predicate, cb.notEqual(root.get("statC"), "NewPnRequest"));


            // Filter by release types
            if (request.getReleaseTypes() != null && !request.getReleaseTypes().isEmpty()) {
                predicate = cb.and(predicate, root.get("releaseType").get("relTypX").in(request.getReleaseTypes()));
            }

            // Filter by module type
            if (request.getModuleType() != null) {
                predicate = cb.and(predicate, cb.equal(root.get("moduleType").get("moduleTypeCode"), request.getModuleType()));
            }

            // Filter by release usage
            if (request.getReleaseUsage() != null) {
                predicate = cb.and(predicate, cb.equal(root.get("releaseUsage").get("usageCode"), request.getReleaseUsage()));
            }

            // Filter by assembly part number
            if (request.getAssemblyPN() != null) {
                predicate = cb.and(predicate, cb.like(root.get("partNumX"), "%" + request.getAssemblyPN() + "%"));
            }

            // Filter by hardware part number
            if (request.getHardwarePN() != null) {
                predicate = cb.and(predicate, cb.like(root.get("hardwarePartR"), "%" + request.getHardwarePN() + "%"));
            }

            // Filter by software part number
            if (request.getSoftwarePN() != null) {
                predicate = cb.and(predicate, cb.like(root.get("swDlSpecR"), "%" + request.getSoftwarePN() + "%"));
            }

            // Filter by application engineer
            if (request.getAppEng() != null) {
                predicate = cb.and(predicate, cb.equal(root.get("engineerCdsidC"), request.getAppEng()));
            }

            // Filter by catch word
            if (request.getCatchWord() != null) {
                predicate = cb.and(predicate, cb.like(root.get("catchWordC"), "%" + request.getCatchWord() + "%"));
            }

            // Filter by calibration number
            if (request.getCalibrationNum() != null) {
                predicate = cb.and(predicate, cb.equal(root.get("calibR"), request.getCalibrationNum()));
            }

            // Filter by main strategy
            if (request.getMainStrategy() != null) {
                predicate = cb.and(predicate, cb.equal(root.get("stratRelC"), request.getMainStrategy()));
            }

            // Filter by concern number
            if (request.getConcernNumber() != null) {
                predicate = cb.and(predicate, cb.equal(root.get("concernC"), request.getConcernNumber()));
            }

            // Date filters
            if (request.getCreatedDateFrom() != null) {
                LocalDateTime createdDateFrom = LocalDateTime.of(LocalDate.parse(request.getCreatedDateFrom()), LocalDateTime.MIN.toLocalTime());
                predicate = cb.and(predicate, cb.greaterThanOrEqualTo(root.get("createS"), createdDateFrom));
            }
            if (request.getCreatedDateTo() != null) {
                LocalDateTime createdDateTo = LocalDateTime.of(LocalDate.parse(request.getCreatedDateTo()), LocalDateTime.MAX.toLocalTime());
                predicate = cb.and(predicate, cb.lessThanOrEqualTo(root.get("createS"), createdDateTo));
            }
            if (request.getReleasedDateFrom() != null) {
                predicate = cb.and(predicate, cb.greaterThanOrEqualTo(root.get("reldY"), LocalDate.parse(request.getReleasedDateFrom())));
            }
            if (request.getReleasedDateTo() != null) {
                predicate = cb.and(predicate, cb.lessThanOrEqualTo(root.get("reldY"), LocalDate.parse(request.getReleasedDateTo())));
            }

            // Set the order by concernC and partR
            assert query != null;
            query.orderBy(cb.asc(root.get("concernC")), cb.asc(root.get("partR")));

            return predicate;
        };
    }


    private Specification<ReleaseRequest> findByCriteriaForReleaseRequests(ReleaseRequestSearchInput releaseRequestSearchInput) {
        return (Root<ReleaseRequest> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) -> {
            Predicate predicate = criteriaBuilder.conjunction();

            int id = Integer.parseInt(releaseRequestSearchInput.getId());

            if (id != -1) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get("relReqK"), id));
            }

            if (StringUtils.isNoneEmpty(releaseRequestSearchInput.getModuleTypeCode())) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(root.get("moduleType").get("moduleTypC"), "%" + releaseRequestSearchInput.getModuleTypeCode() + "%"));
            }

            if (StringUtils.isNoneEmpty(releaseRequestSearchInput.getCalibrationLevel())) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(root.get("calRLevelR"), "%" + releaseRequestSearchInput.getCalibrationLevel() + "%"));
            }

            if (StringUtils.isNoneEmpty(releaseRequestSearchInput.getStatus())) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(root.get("statusC"), "%" + releaseRequestSearchInput.getStatus() + "%"));
            }

            if (StringUtils.isNoneEmpty(releaseRequestSearchInput.getOwner())) {
                predicate = criteriaBuilder.and(predicate, criteriaBuilder.like(root.get("createUserC"), "%" + releaseRequestSearchInput.getOwner() + "%"));
            }

            String modelYear = releaseRequestSearchInput.getModelYear();
            String program = releaseRequestSearchInput.getProgram();
            String engine = releaseRequestSearchInput.getEngine();

            // Subquery for WPCMS01_PGM_DESC based on modelYear, program, and engine
            if (!StringUtils.isBlank(modelYear) || !StringUtils.isBlank(program) || !StringUtils.isBlank(engine)) {
                // Create a subquery for the PGM_RELEASE_REQUEST table
                assert query != null;
                Subquery<Long> subquery = query.subquery(Long.class);
                Root<PgmReleaseRequest> subRoot = subquery.from(PgmReleaseRequest.class);
                subquery.select(subRoot.get("releaseRequest").get("relReqK"));

                // Join with ProgramDescription (WPCMS01_PGM_DESC)
                Join<PgmReleaseRequest, ProgramDescription> join = subRoot.join("programDescription");

                Predicate subPredicate = criteriaBuilder.conjunction();

                // Check for modelYear
                if (!StringUtils.isBlank(modelYear)) {
                    subPredicate = criteriaBuilder.and(subPredicate, criteriaBuilder.like(join.get("mdlYrR"), "%" + modelYear + "%"));
                }

                // Check for program
                if (!StringUtils.isBlank(program)) {
                    subPredicate = criteriaBuilder.and(subPredicate, criteriaBuilder.like(join.get("pgmN"), "%" + program + "%"));
                }

                // Check for engine
                if (!StringUtils.isBlank(engine)) {
                    subPredicate = criteriaBuilder.and(subPredicate, criteriaBuilder.like(join.get("engN"), "%" + engine + "%"));
                }

                subquery.where(subPredicate);
                predicate = criteriaBuilder.and(predicate, root.get("relReqK").in(subquery));
            }


            return predicate;
        };
    }
}