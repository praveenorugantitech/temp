package com.ford.gpcse.bo;

import com.ford.gpcse.dto.LookupPartFirmwareDto;
import com.ford.gpcse.dto.LookupProgramDescriptionDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class FirmwareResponse {
    private String assemblyPN;
    private String calibration;
    private String catchWord;
    private String dRCdsId;
    private String notice;
    private String releaseUsage;
    private String hardwarePN;
    private String coreHardwarePN;
    private String mainMicroType;
    private String supplier;
    private String coreHwEng;
    private String softwarePN;
    private String mainStrategy;
    private String chipId;
    private String calibrator;
    private List<LookupProgramDescriptionDto> programDescription;
    private String lineage;
    private List<LookupPartFirmwareDto> firmware;
    private String releaseType;
    private String concern;
    private String wersConcernDescription;
}
