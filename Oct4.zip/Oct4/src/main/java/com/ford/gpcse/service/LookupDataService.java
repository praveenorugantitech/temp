package com.ford.gpcse.service;

import com.ford.gpcse.bo.MicroTypeView;
import com.ford.gpcse.bo.ModuleTypeView;
import com.ford.gpcse.bo.ReleaseRequestResponse;
import com.ford.gpcse.bo.SupplierView;
import com.ford.gpcse.dto.ProgramDescriptionDto;

import java.util.List;

public interface LookupDataService {
    List<SupplierView> fetchActiveSuppliers();

    List<ModuleTypeView> fetchActiveModuleTypes();

    List<MicroTypeView> fetchReleasedMicroTypesByModuleType(String moduleTypC);

    List<String> fetchActiveModuleNames();

    List<String> fetchActiveMicroNames();

    List<ProgramDescriptionDto> fetchDistinctPrograms();

    List<ReleaseRequestResponse> fetchAllReleaseRequests();

}
