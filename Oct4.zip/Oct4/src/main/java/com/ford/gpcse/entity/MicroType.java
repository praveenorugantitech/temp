package com.ford.gpcse.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR19_MICRO_TYP")
public class MicroType {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PCMR19_MICRO_TYP_C")
    private Long microTypC;

    @Column(name = "PCMR19_MICRO_TYP_X")
    private String microTypX;

    @Column(name = "PCMR19_ARCH_F")
    private String archF;

    @Column(name = "PCMR19_MICRO_TYP_OWNR_CDSID_C")
    private String microTypOwnrCdsidC;

    @Column(name = "PCMR19_CREATE_USER_C")
    private String createUserC;

    @NotNull
    @CreationTimestamp
    @Column(name = "PCMR19_CREATE_S", nullable = false, updatable = false)
    private LocalDateTime createS;

    @Column(name = "PCMR19_LAST_UPDT_USER_C")
    private String lastUpdtUserC;

    @NotNull
    @UpdateTimestamp
    @Column(name = "PCMR19_LAST_UPDT_S")
    private LocalDateTime lastUpdtS;

    @ManyToOne
    @JoinColumn(name = "PCMR14_MODULE_TYP_C", referencedColumnName = "PCMR14_MODULE_TYP_C")
    private ModuleType moduleType;

    @ManyToOne
    @JoinColumn(name = "PCMR17_SUPL_C", referencedColumnName = "PCMR17_SUPL_C")
    private Supplier supplier;

    @Column(name = "PCMR19_MICRO_TYP_STAT_C")
    private String microTypStatC;

    @Column(name = "PCMR19_CAN_TYP_C")
    private String canTypC;

    @Column(name = "PCMR19_OTA_TYP_C")
    private String otaTypC;

    @Column(name = "PCMR19_SW_REFLASH_TIME_N")
    private String swReflashTimeN;

    @Column(name = "PCMR19_MICRO_PROTO_TYP_X")
    private String microProtoTypX;

}
