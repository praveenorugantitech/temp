package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.MicroTypeView;
import com.ford.gpcse.bo.ModuleTypeView;
import com.ford.gpcse.bo.ReleaseRequestResponse;
import com.ford.gpcse.bo.SupplierView;
import com.ford.gpcse.dto.ProgramDescriptionDto;
import com.ford.gpcse.entity.MicroType;
import com.ford.gpcse.entity.ModuleType;
import com.ford.gpcse.entity.ReleaseRequest;
import com.ford.gpcse.entity.Supplier;
import com.ford.gpcse.exception.ResourceNotFoundException;
import com.ford.gpcse.repository.*;
import com.ford.gpcse.service.LookupDataService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class LookupDataServiceImpl implements LookupDataService {

    private final SupplierRepository supplierRepository;
    private final ModuleTypeRepository moduleTypeRepository;
    private final MicroTypeRepository microTypeRepository;
    private final ModuleNameRepository moduleNameRepository;
    private final ProcessorRepository processorRepository;
    private final ProgramDescriptionRepository programDescriptionRepository;
    private final ReleaseRequestRepository releaseRequestRepository;

    @Override
    public List<SupplierView> fetchActiveSuppliers() {
        List<Supplier> suppliers = supplierRepository.fetchActiveSuppliers();

        if (suppliers.isEmpty()) {
            throw new ResourceNotFoundException("No Suppliers");
        }

        List<SupplierView> supplierViews = new ArrayList<>();
        suppliers.forEach(supplier -> {
            SupplierView supplierView = new SupplierView();
            supplierView.setSupplierCode(supplier.getSuplC());
            supplierView.setSupplierName(supplier.getSuplX());
            supplierViews.add(supplierView);
        });

        return supplierViews;
    }

    @Override
    public List<ModuleTypeView> fetchActiveModuleTypes() {
        List<ModuleType> moduleTypes = moduleTypeRepository.findActiveModuleTypes();

        if (moduleTypes.isEmpty()) {
            throw new ResourceNotFoundException("No Module Types");
        }

        List<ModuleTypeView> moduleTypeViews = new ArrayList<>();
        moduleTypes.forEach(moduleType -> {
            ModuleTypeView moduleTypeView = new ModuleTypeView();
            moduleTypeView.setModuleTypeCode(moduleType.getModuleTypC());
            moduleTypeView.setModuleTypeName(moduleType.getModuleTypX());
            moduleTypeViews.add(moduleTypeView);
        });

        return moduleTypeViews;
    }

    @Override
    public List<MicroTypeView> fetchReleasedMicroTypesByModuleType(String moduleTypeCode) {
        List<MicroType> microTypes = microTypeRepository.fetchReleasedMicroTypesByModuleType(moduleTypeCode);

        if (microTypes.isEmpty()) {
            throw new ResourceNotFoundException("No MicroTypes found for given module type");
        }

        List<MicroTypeView> microTypeViews = new ArrayList<>();
        microTypes.forEach(microType -> {
            MicroTypeView microTypeView = new MicroTypeView();
            microTypeView.setMicroTypeCode(microType.getMicroTypC());
            microTypeView.setMicroTypeName(microType.getMicroTypX());
            microTypeViews.add(microTypeView);
        });

        return microTypeViews;
    }

    @Override
    public List<String> fetchActiveModuleNames() {
        List<String> moduleNames = moduleNameRepository.findActiveModuleNames();

        if (moduleNames.isEmpty()) {
            throw new ResourceNotFoundException("No Module Names");
        }

        return moduleNames;
    }

    @Override
    public List<String> fetchActiveMicroNames() {
        List<String> microNames = processorRepository.fetchActiveMicroNames();

        if (microNames.isEmpty()) {
            throw new ResourceNotFoundException("No Micro Names");
        }

        return microNames;
    }

    @Override
    public List<ProgramDescriptionDto> fetchDistinctPrograms() {
        return programDescriptionRepository.fetchDistinctPrograms();
    }


    @Override
    public List<ReleaseRequestResponse> fetchAllReleaseRequests() {
        List<ReleaseRequest> releaseRequests = releaseRequestRepository.findAllByOrderByRelReqKDesc();
        List<ReleaseRequestResponse> releaseRequestResponses = new ArrayList<>();

        releaseRequests.forEach(releaseRequest ->
                releaseRequestResponses.add(ReleaseRequestResponse.builder()
                        .requestId(releaseRequest.getRelReqK())
                        .module(releaseRequest.getModuleType().getModuleTypC())
                        .rLevel(releaseRequest.getCalRLevelR())
                        .my(releaseRequest.getProgramReleaseRequests() != null && !releaseRequest.getProgramReleaseRequests().isEmpty() ? releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription().getMdlYrR() : null)
                        .prog(releaseRequest.getProgramReleaseRequests() != null && !releaseRequest.getProgramReleaseRequests().isEmpty() ? releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription().getPgmN() : null)
                        .engine(releaseRequest.getProgramReleaseRequests() != null && !releaseRequest.getProgramReleaseRequests().isEmpty() ? releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription().getEngN() : null)
                        .status(releaseRequest.getStatusC())
                        .created(releaseRequest.getCreateS().format(DateTimeFormatter.ofPattern("MMM dd, yyyy")))
                        .owner(releaseRequest.getCreateUserC())
                        .build())
        );
        return releaseRequestResponses;
    }
}
