package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR39_LABEL_USG")
public class LabelUsg {
    @Id
    @Column(name = "PCMR39_LABEL_USG_K", nullable = false)
    private String labelUsgK;

    @Column(name = "PCMR39_LABEL_USG_X", nullable = false)
    private String labelUsgX;

    @Column(name = "PCMR39_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR39_CREATE_S", nullable = false)
    private LocalDateTime createS;

    @Column(name = "PCMR39_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR39_LAST_UPDT_S", nullable = false)
    private LocalDateTime lastUpdtS;
}
