package com.ford.gpcse.controller;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.*;
import com.ford.gpcse.service.SearchDataService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1_0/search")
@Tag(description = "Search based on Wers Concern, Wers Notice, Program, Release Status, Part Number/Catchword/Date Range, Release Request, Production Part Number, Parts by Firmware, Data For Prism Input Based On Part Number and Wers Text based on Wers Concern.", name = "Search Data")
public class SearchDataController {

    private final SearchDataService searchDataService;

    @LoggingAspect
    @TrackExecutionTime
    @GetMapping("/wers-concern/{wersConcern}")
    @Operation(description = "Wers Concern Search", summary = "Wers Concern Search")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully retrieved resource"), @ApiResponse(responseCode = "404", description = "Resource not found")})
    public List<FirmwareResponse> fetchFirmwareDetailsByWersConcern(@PathVariable String wersConcern) {
        return searchDataService.fetchFirmwareDetailsByWersConcern(wersConcern);
    }

    @LoggingAspect
    @TrackExecutionTime
    @GetMapping("/wers-notice/{wersNotice}")
    @Operation(description = "Wers Notice Search", summary = "Wers Notice Search")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully retrieved resource"), @ApiResponse(responseCode = "404", description = "Resource not found")})
    public List<FirmwareResponse> fetchFirmwareDetailsByWersNotice(@PathVariable String wersNotice) {
        return searchDataService.fetchFirmwareDetailsByWersNotice(wersNotice);
    }

    @LoggingAspect
    @TrackExecutionTime
    @PostMapping("/programs")
    @Operation(description = "Program Search", summary = "Program Search")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully retrieved resource"), @ApiResponse(responseCode = "404", description = "Resource not found")})
    public List<FirmwareResponse> fetchFirmwareDetailsByPrograms(@RequestBody List<Long> programKeys) {
        return searchDataService.fetchFirmwareDetailsByPrograms(programKeys);
    }

    @LoggingAspect
    @TrackExecutionTime
    @GetMapping("/release-status")
    @Operation(description = "Release Status Search", summary = "Release Status Search")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully retrieved resource"), @ApiResponse(responseCode = "404", description = "Resource not found")})
    public List<ReleaseStatusSearchResponse> fetchReleaseStatusDetails() {
        return searchDataService.fetchReleaseStatusDetails();
    }

    @LoggingAspect
    @TrackExecutionTime
    @PostMapping("/part-number")
    @Operation(description = "Part Number/Catchword/Date Range Search", summary = "Part Number/Catchword/Date Range Search")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully retrieved resource"), @ApiResponse(responseCode = "404", description = "Resource not found")})
    public List<PartNumberSearchResponse> fetchFirmwareDetailsByPartNumber(@RequestBody PartNumberSearchRequest partNumberSearchRequest) {
        return searchDataService.fetchFirmwareDetailsByPartNumber(partNumberSearchRequest);
    }

    @LoggingAspect
    @TrackExecutionTime
    @PostMapping("/release-request")
    @Operation(description = "Release Request Search", summary = "Release Request Search")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully retrieved resource"), @ApiResponse(responseCode = "404", description = "Resource not found")})
    public List<ReleaseRequestResponse> fetchReleaseRequests(ReleaseRequestSearchInput releaseRequestSearchInput) {
        return searchDataService.fetchReleaseRequests(releaseRequestSearchInput);
    }

    @TrackExecutionTime
    @LoggingAspect
    @PostMapping(value = "/production-part-number")
    @Operation(
            summary = "Production Part Number Search",
            description = "Production Part Number Search"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public ResponseEntity<List<FindProductionPartNumberResponse>> findProductionPartNumber(@RequestBody FindProductionPartNumberRequest findProductionPartNumberRequest) {
        return ResponseEntity.ok(searchDataService.findProductionPartNumber(findProductionPartNumberRequest));
    }

    @TrackExecutionTime
    @LoggingAspect
    @PostMapping(value = "/parts-by-firmware")
    @Operation(
            summary = "Find Parts by Firmware Search",
            description = "Finds parts by firmware based on the current and replace PBL Search"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public ResponseEntity<List<PartFirmwareResponse>> findPartsByFirmware(@RequestBody ReplacePblRequest replacePblRequest) {
        return ResponseEntity.ok(searchDataService.findPartsByFirmware(replacePblRequest));
    }

    @TrackExecutionTime
    @LoggingAspect
    @GetMapping(value = "/data-prism-input/part-number/{partNumber}")
    @Operation(
            summary = "Data For Prism Input based on Part Number Search",
            description = "Data For Prism Input based on Part Number Search"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public ResponseEntity<PrismDataInputResponse> dataForPrismInputBasedOnPartNumber(@PathVariable("partNumber") String partNumber) {
        return ResponseEntity.ok(searchDataService.dataForPrismInputBasedOnPartNumber(partNumber));
    }

    @TrackExecutionTime
    @LoggingAspect
    @GetMapping(value = "/wers-text/wers-concern/{wersConcern}")
    @Operation(
            summary = "Wers Text Based on Wers Concern Search",
            description = "Wers Text Based on Wers Concern Search"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public ResponseEntity<String> fetchWersTextByConcern(@PathVariable("wersConcern") String wersConcern) {
        return ResponseEntity.ok(searchDataService.fetchWersTextByConcern(wersConcern));
    }


}
