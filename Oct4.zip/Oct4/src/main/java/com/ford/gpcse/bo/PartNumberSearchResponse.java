package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class PartNumberSearchResponse {
    private String assemblyPN;
    private String hardwarePN;
    private String supplier;
    private String catchWord;
    private String calibrationNum;
    private String status;
    private String dateCreated;
    private String releaseType;
    private String releaseUsage;
    private String wersConcernDescription;
    private String concernNumber;
    private String softwarePN;
    private String comments;
    private String buildLevel;
    private String releasePriority;
    private String releasePriorityDetail;
}
