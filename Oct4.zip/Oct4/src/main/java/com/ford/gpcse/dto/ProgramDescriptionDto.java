package com.ford.gpcse.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProgramDescriptionDto {

    private Long pgmK;
    private String mdlYrR;
    private String pgmN;
    private String platN;
    private String engN;
    private String transN;

}
