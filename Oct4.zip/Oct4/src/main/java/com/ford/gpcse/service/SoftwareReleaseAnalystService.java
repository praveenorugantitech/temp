package com.ford.gpcse.service;

import com.ford.gpcse.bo.EditPartNumbersRequest;

public interface SoftwareReleaseAnalystService {

    void editPart(EditPartNumbersRequest editPartNumbersRequest);
}
