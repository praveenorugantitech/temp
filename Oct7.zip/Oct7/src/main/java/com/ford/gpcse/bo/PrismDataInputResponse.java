package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class PrismDataInputResponse {

    private String inputFile;
    private String hardwarePn;
    private String modulePn;
    private String engineSize;
    private String catchWord;
    private String vehicleCal;
    private String vehicleAppl;
    private String wersNotice;
    private String pdxPartNumber;
    private String calibPartNumber;
    private String chipId;
    private String part2PartNumber;
    private String comments;


}
