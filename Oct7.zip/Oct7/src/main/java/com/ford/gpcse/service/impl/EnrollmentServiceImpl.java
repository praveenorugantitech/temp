package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.SupplierEnrollmentRequest;
import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.model.Email;
import com.ford.gpcse.service.EnrollmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EnrollmentServiceImpl implements EnrollmentService {
    private final EmailService emailService;

    @Override
    public String supplierEnrollment(SupplierEnrollmentRequest supplierEnrollmentRequest) {
        sendSupplierEnrollmentEmail(supplierEnrollmentRequest);
        return "Your request has been submitted.";
    }

    private void sendSupplierEnrollmentEmail(SupplierEnrollmentRequest supplierEnrollmentRequest) {
        String emailBody = "<HTML><HEAD></HEAD><BODY>" +
                "<P>User ID: " + supplierEnrollmentRequest.getUserId() +
                "<P>First Name: " + supplierEnrollmentRequest.getFirstName() +
                "<P>Last Name: " + supplierEnrollmentRequest.getLastName() +
                "<P>Email Address: " + supplierEnrollmentRequest.getEmailAddress() +
                "<P>Comments: " + supplierEnrollmentRequest.getComments() +
                "</Body></HTML>";
        Email email = Email.builder()
                .from("")// pcserel@ford.com
                .to(List.of(""))//"achopp@ford.com; icelikk2@ford.com; bnathan4@ford.com; mgunawar@ford.com;"
                .subject("Firmware User")
                .body(emailBody)
                .build();
        emailService.sendMail(email);

    }
}
