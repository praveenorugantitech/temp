package com.ford.gpcse.service;

import com.ford.gpcse.bo.*;
import com.ford.gpcse.dto.ProgramDescriptionDto;

import java.util.List;

public interface LookupDataService {
    List<SupplierView> fetchActiveSuppliers();

    List<ModuleTypeView> fetchActiveModuleTypes();

    List<MicroTypeView> fetchReleasedMicroTypesByModuleType(String moduleTypC);

    List<String> fetchActiveModuleNames();

    List<String> fetchActiveMicroNames();

    List<ProgramDescriptionDto> fetchDistinctPrograms();

    List<ReleaseRequest> fetchAllReleaseRequests();

    List<ReleaseStatus> fetchReleaseStatusDetails();

    List<ModuleBaseInformation> fetchModuleBaseInformation(String userId);

    List<PartFirmwareResponse> findPartsByFirmware(ReplacePblRequest replacePblRequest);

    PrismDataInputResponse fetchPrismInputDataBasedOnPartNumber(String partNumber);

}
