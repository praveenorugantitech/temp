package com.ford.gpcse.service;

import com.ford.gpcse.bo.*;

import java.util.List;

public interface SearchDataService {

    List<FirmwareResponse> fetchFirmwareDetailsByWersConcern(String wersConcern);

    List<FirmwareResponse> fetchFirmwareDetailsByWersNotice(String wersNotice);

    List<FirmwareResponse> fetchFirmwareDetailsByPrograms(List<Long> programKeys);

    List<PartNumberSearchResponse> fetchFirmwareDetailsByPartNumber(PartNumberSearchRequest partNumberSearchRequest);

    List<ReleaseRequest> fetchReleaseRequests(ReleaseRequestSearchInput releaseRequestSearchInput);

    List<ProductionPartNumberSearchResponse> fetchProductionPartNumber(ProductionPartNumberSearchRequest productionPartNumberSearchRequest);

    String fetchWersTextByConcern(String wersConcern);


}
