package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR08_CATCHWORD")
public class Catchword {
    @Id
    @Column(name = "PCMR08_CATCHWORD_C", nullable = false)
    private String catchwordC;
    @Column(name = "PCMR08_CATCHWORD_TYP_C")
    private String catchwordTypC;
    @Column(name = "PCMR08_CREATE_S")
    private LocalDateTime createS;
    @Column(name = "PCMR08_LAST_UPDT_S")
    private LocalDateTime lastUpdtS;
}
