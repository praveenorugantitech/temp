package com.ford.gpcse.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR03_FIRMWARE")
public class Firmware {

    @Id
    @Column(name = "PCMR03_FIRMWARE_K")
    private Long firmwareK;

    @Column(name = "PCM002_ROLE_K")
    private Long roleKey;

    @Column(name = "PCMR41_FIRMWARE_TYP_C")
    private String firmwareTypC;

    @Column(name = "PCMR03_FIRMWARE_X")
    private String firmwareX;

    @Column(name = "PCMR03_MAX_LEN_R")
    private Long maxLenR;

    @Column(name = "PCMR03_SORT_ORD_R")
    private Long sortOrdR;

    @Column(name = "PCMR03_MUTUAL_EXCLUSIVE_GRP_R")
    private Long mutualExclusiveGrpR;

    @Column(name = "PCMR03_FIRMWARE_N")
    private String firmwareN;

    @Column(name = "PCMR03_REVW_RESP_C")
    private String revwRespC;

    @Column(name = "PCMR03_FIRMWARE_CATG_N")
    private String firmwareCatgN;

    @Column(name = "PCMR03_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR03_CREATE_S", nullable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR03_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR03_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    // Bidirectional relationship (optional)
    @OneToMany(mappedBy = "firmware", cascade = CascadeType.ALL)
    private List<FirmwareItem> firmwareItems;

    // Bidirectional relationship with PartFirmware (optional)
    @OneToMany(mappedBy = "firmware", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<PartFirmware> partFirmwares;


}
