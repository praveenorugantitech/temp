package com.ford.gpcse.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCM003_USER_ROLE")
public class UserRole {

    @EmbeddedId
    private UserRoleId userRoleId;

    @ManyToOne
    @JoinColumn(name = "PCM001_USER_CDSID_C", referencedColumnName = "PCM001_USER_CDSID_C", insertable = false, updatable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "PCM002_ROLE_K", referencedColumnName = "PCM002_ROLE_K", insertable = false, updatable = false)
    private Role role;

    @Column(name = "PCM003_CREATE_USER_C", length = 8, nullable = false)
    private String createUserC;

    @NotNull
    @CreationTimestamp
    @Column(name = "PCM003_CREATE_S", nullable = false, updatable = false)
    private LocalDateTime createS;

    @Column(name = "PCM003_LAST_UPDT_USER_C", length = 8, nullable = false)
    private String lastUpdtUserC;

    @NotNull
    @UpdateTimestamp
    @Column(name = "PCM003_LAST_UPDT_S", nullable = false)
    private LocalDateTime lastUpdtS;

}
