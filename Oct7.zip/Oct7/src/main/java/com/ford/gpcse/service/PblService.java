package com.ford.gpcse.service;

import com.ford.gpcse.bo.CreatePblRequest;
import com.ford.gpcse.bo.ReplacePblRequest;

public interface PblService {

    void createPbl(CreatePblRequest createPblRequest);

    void replacePbl(ReplacePblRequest replacePblRequest);
}
