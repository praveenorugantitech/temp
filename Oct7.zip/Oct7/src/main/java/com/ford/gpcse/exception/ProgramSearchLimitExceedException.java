package com.ford.gpcse.exception;


public class ProgramSearchLimitExceedException extends RuntimeException {
    public ProgramSearchLimitExceedException(String message) {
        super(message);
    }
}

