package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class Part2PdxRequest {
    private String releaseType;
    private String moduleTypeCode;
    private Long microTypeCode;
    private String createUser;
    private String lastUpdateUser;
    private String ggdsVersion;
    private String swdlVersion;
    private String partNumber;
    private String description;
    private String uploadedToVSEM;
}
