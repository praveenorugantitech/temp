package com.ford.gpcse.repository;

import com.ford.gpcse.dto.UserRoleDto;
import com.ford.gpcse.entity.UserRole;
import com.ford.gpcse.entity.UserRoleId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRoleRepository extends JpaRepository<UserRole, UserRoleId> {

    @Query("SELECT new com.ford.gpcse.dto.UserRoleDto(u.frstN, u.lstN, u.emailAddrX, " +
            "(SELECT s.suplX FROM Supplier s WHERE s.suplC = r.supplier.suplC)) " +
            "FROM User u " +
            "JOIN u.userRoles ur " +
            "JOIN ur.role r " +
            "JOIN r.firmwareRoles fr "+
            "JOIN fr.firmware f " +
            "WHERE f.firmwareK = :firmwareK " +
            "ORDER BY r.supplier.suplC, u.userCdsidC")
    List<UserRoleDto> findUserRolesByFirmwareKey(@Param("firmwareK") Long firmwareK);

}
