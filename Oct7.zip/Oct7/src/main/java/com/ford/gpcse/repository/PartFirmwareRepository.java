package com.ford.gpcse.repository;

import com.ford.gpcse.dto.LookupPartFirmwareDto;
import com.ford.gpcse.entity.PartFirmware;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PartFirmwareRepository extends JpaRepository<PartFirmware, String> {

    @Query("SELECT COUNT(f) FROM PartFirmware f WHERE f.fileN = :fileN")
    Long countByfileN(@Param("fileN") String fileN);

    @Query("SELECT  new com.ford.gpcse.dto.LookupPartFirmwareDto(f.firmwareN, pf.fileN, pf.aprvdByCdsidC, f.firmwareCatgN, pf.aprvdY) " +
            "FROM PartFirmware pf " +
            "INNER JOIN Firmware f ON pf.firmware.firmwareK = f.firmwareK " +
            "WHERE pf.part.partR = :partR " +
            "ORDER BY f.sortOrdR, f.firmwareCatgN, f.firmwareN")
    List<LookupPartFirmwareDto> findPartFirmwareByPartNumber(@Param("partR") String partR);

}
