package com.ford.gpcse.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class WersTextPartDescriptionDto {

    private Long pgmK;
    private String mdlYrR;
    private String pgmN;
    private String platN;
    private String engN;
    private String transN;
}
