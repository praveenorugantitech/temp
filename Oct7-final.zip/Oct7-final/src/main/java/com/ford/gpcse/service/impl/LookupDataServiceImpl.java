package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.*;
import com.ford.gpcse.dto.*;
import com.ford.gpcse.entity.Firmware;
import com.ford.gpcse.entity.MicroType;
import com.ford.gpcse.entity.ModuleType;
import com.ford.gpcse.entity.Supplier;
import com.ford.gpcse.exception.FirmwareAlreadyRequestedException;
import com.ford.gpcse.exception.ResourceNotFoundException;
import com.ford.gpcse.exception.UnusedReleaseException;
import com.ford.gpcse.repository.*;
import com.ford.gpcse.service.LookupDataService;
import com.ford.gpcse.util.DateFormatterUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
@RequiredArgsConstructor
public class LookupDataServiceImpl implements LookupDataService {

    private final SupplierRepository supplierRepository;
    private final ModuleTypeRepository moduleTypeRepository;
    private final MicroTypeRepository microTypeRepository;
    private final ModuleNameRepository moduleNameRepository;
    private final ProcessorRepository processorRepository;
    private final ProgramDescriptionRepository programDescriptionRepository;
    private final ReleaseRequestRepository releaseRequestRepository;
    private final PartRepository partRepository;
    private final FirmwareItemRepository firmwareItemRepository;
    private final PartFirmwareRepository partFirmwareRepository;
    private final FirmwareRepository firmwareRepository;
    private final UserRoleRepository userRoleRepository;
    private static final Map<String, List<String>> moduleTypeToReleaseTypes = new HashMap<>();

    static {
        // Populate the mapping from module types to release types
        moduleTypeToReleaseTypes.put("PCM", Arrays.asList("AREUL", "AFD", "AFDCX", "AFG", "AFGO", "ARNAL", "HRDCN", "HARDW", "HWPT", "PSUPR"));
        moduleTypeToReleaseTypes.put("GSM", Collections.singletonList("GSMA"));
        moduleTypeToReleaseTypes.put("HPCM", Arrays.asList("HASM", "HASMS"));
        moduleTypeToReleaseTypes.put("TCM", Arrays.asList("DPS6", "UTCU2", "HWUTC", "TSUPS", "HWPUT", "HWCUT"));
        moduleTypeToReleaseTypes.put("TRCM", Collections.singletonList("TRCMA"));
        moduleTypeToReleaseTypes.put("VCM", Arrays.asList("VCMA", "VCMH", "VCMHP", "VCMHC"));
        moduleTypeToReleaseTypes.put("DCU", Collections.singletonList("DCUA"));
        moduleTypeToReleaseTypes.put("DLCM", Arrays.asList("DLCMA", "DLCMS"));
    }


    @Override
    public List<SupplierView> fetchActiveSuppliers() {
        List<Supplier> suppliers = supplierRepository.fetchActiveSuppliers();

        if (suppliers.isEmpty()) {
            throw new ResourceNotFoundException("No Suppliers");
        }

        List<SupplierView> supplierViews = new ArrayList<>();
        suppliers.forEach(supplier -> {
            SupplierView supplierView = new SupplierView();
            supplierView.setSupplierCode(supplier.getSuplC());
            supplierView.setSupplierName(supplier.getSuplX());
            supplierViews.add(supplierView);
        });

        return supplierViews;
    }

    @Override
    public List<ModuleTypeView> fetchActiveModuleTypes() {
        List<ModuleType> moduleTypes = moduleTypeRepository.findActiveModuleTypes();

        if (moduleTypes.isEmpty()) {
            throw new ResourceNotFoundException("No Module Types");
        }

        List<ModuleTypeView> moduleTypeViews = new ArrayList<>();
        moduleTypes.forEach(moduleType -> {
            ModuleTypeView moduleTypeView = new ModuleTypeView();
            moduleTypeView.setModuleTypeCode(moduleType.getModuleTypC());
            moduleTypeView.setModuleTypeName(moduleType.getModuleTypX());
            moduleTypeViews.add(moduleTypeView);
        });

        return moduleTypeViews;
    }

    @Override
    public List<MicroTypeView> fetchReleasedMicroTypesByModuleType(String moduleTypeCode) {
        List<MicroType> microTypes = microTypeRepository.fetchReleasedMicroTypesByModuleType(moduleTypeCode);

        if (microTypes.isEmpty()) {
            throw new ResourceNotFoundException("No Micro Types found for given module type");
        }

        List<MicroTypeView> microTypeViews = new ArrayList<>();
        microTypes.forEach(microType -> {
            MicroTypeView microTypeView = new MicroTypeView();
            microTypeView.setMicroTypeCode(microType.getMicroTypC());
            microTypeView.setMicroTypeName(microType.getMicroTypX());
            microTypeViews.add(microTypeView);
        });

        return microTypeViews;
    }

    @Override
    public List<String> fetchReleaseTypesByModuleType(String moduleTypeCode) {
        List<String> releaseTypes = moduleTypeToReleaseTypes.getOrDefault(moduleTypeCode, Collections.emptyList());

        if (releaseTypes.isEmpty()) {
            throw new ResourceNotFoundException("No Release Types found for given module type");
        }

        return releaseTypes;
    }

    @Override
    public List<String> fetchActiveModuleNames() {
        List<String> moduleNames = moduleNameRepository.findActiveModuleNames();

        if (moduleNames.isEmpty()) {
            throw new ResourceNotFoundException("No Module Names");
        }

        return moduleNames;
    }

    @Override
    public List<String> fetchActiveMicroNames() {
        List<String> microNames = processorRepository.fetchActiveMicroNames();

        if (microNames.isEmpty()) {
            throw new ResourceNotFoundException("No Micro Names");
        }

        return microNames;
    }

    @Override
    public List<ProgramDescriptionDto> fetchDistinctPrograms() {
        List<ProgramDescriptionDto> programDescriptionDtos = programDescriptionRepository.fetchDistinctPrograms();

        if (programDescriptionDtos.isEmpty()) {
            throw new ResourceNotFoundException("No Programs");
        }

        return programDescriptionDtos;
    }

    @Override
    public List<ReleaseRequest> fetchAllReleaseRequests() {
        List<com.ford.gpcse.entity.ReleaseRequest> releaseRequests = releaseRequestRepository.findAllByOrderByRelReqKDesc();

        if (releaseRequests.isEmpty()) {
            throw new ResourceNotFoundException("No Release Requests");
        }

        return releaseRequests.stream().map(releaseRequest -> new ReleaseRequest(releaseRequest.getRelReqK(),
                releaseRequest.getModuleType().getModuleTypC(),
                releaseRequest.getCalRLevelR(),
                releaseRequest.getProgramReleaseRequests() != null && !releaseRequest.getProgramReleaseRequests().isEmpty() ? releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription().getMdlYrR() : null,
                releaseRequest.getProgramReleaseRequests() != null && !releaseRequest.getProgramReleaseRequests().isEmpty() ? releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription().getPgmN() : null,
                releaseRequest.getProgramReleaseRequests() != null && !releaseRequest.getProgramReleaseRequests().isEmpty() ? releaseRequest.getProgramReleaseRequests().get(0).getProgramDescription().getEngN() : null,
                releaseRequest.getStatusC(),
                releaseRequest.getCreateS().format(DateTimeFormatter.ofPattern("MMM dd, yyyy")),
                releaseRequest.getCreateUserC())).toList();
    }

    @Override
    public List<ReleaseStatus> fetchReleaseStatusDetails() {
        List<ReleaseStatusDto> releaseStatusDtos = partRepository.findReleaseStatusDetails();
        if (releaseStatusDtos.isEmpty()) {
            throw new ResourceNotFoundException("No Release Status Details");
        }

        return releaseStatusDtos.stream()
                .map(releaseStatusDto ->
                        new ReleaseStatus(releaseStatusDto.getConcernC(),
                                releaseStatusDto.getPartR(),
                                releaseStatusDto.getRelTypX(),
                                releaseStatusDto.getStatC(),
                                DateFormatterUtility.formatDateMonthAbr(releaseStatusDto.getConcernY()))).toList();
    }

    @Override
    public List<ModuleBaseInformation> fetchModuleBaseInformation(String userId) {
        List<ModuleBaseInformationDto> moduleBaseInformationDtos = partRepository.fetchModuleBaseInformation(userId);
        if (moduleBaseInformationDtos.isEmpty()) {
            throw new ResourceNotFoundException("No Module Base Information");
        }
        return moduleBaseInformationDtos.stream().map(moduleBaseInformationDto -> new ModuleBaseInformation(moduleBaseInformationDto.getConcernC(), moduleBaseInformationDto.getPartR())).toList();
    }

    @Override
    public List<PartFirmwareResponse> findPartsByFirmware(ReplacePblRequest replacePblRequest) {
        // Check if the current pbl exists
        Long currentPblcount = partFirmwareRepository.countByfileN(replacePblRequest.getCurrentPbl());

        if (currentPblcount == 0) {
            throw new UnusedReleaseException(replacePblRequest.getCurrentPbl());
        }

        // Check if the new pbl exists
        Long newPblCount = firmwareItemRepository.countByFirmwareItmX(replacePblRequest.getNewPbl());

        if (newPblCount > 0) {
            throw new FirmwareAlreadyRequestedException(replacePblRequest.getNewPbl());
        }

        // fetch the PBL records

        List<PartFirwareDto> parts = partRepository.findPartsByFirmware(replacePblRequest.getNewPbl(), List.of("All"));

        if (parts.isEmpty()) {
            throw new ResourceNotFoundException("No Records were found.");
        }
        return convertToPartFirmwareResponse(parts);
    }

    @Override
    public PrismDataInputResponse fetchPrismInputDataBasedOnPartNumber(String partNumber) {
        PrismDataInputDto prismDataInputDto = partRepository.fetchPrismInputDataBasedOnPartNumber(partNumber);
        if (prismDataInputDto == null) {
            throw new ResourceNotFoundException("No records found");
        }
        return PrismDataInputResponse.builder()
                .calibPartNumber(prismDataInputDto.getStratCalibPartR())
                .part2PartNumber(firmwareRepository.fetchFileN(prismDataInputDto.getPartR(), "%Part II%"))
                .inputFile(prismDataInputDto.getStratRelC())
                .pdxPartNumber(firmwareRepository.fetchFileN(prismDataInputDto.getPartR(), "%PDX%"))
                .catchWord(prismDataInputDto.getCatchWordC())
                .chipId(prismDataInputDto.getChipD())
                .comments(prismDataInputDto.getWersNtcR())
                .engineSize(prismDataInputDto.getEngine())
                .hardwarePn(prismDataInputDto.getHardwarePartR())
                .modulePn(prismDataInputDto.getPartR())
                .vehicleAppl(prismDataInputDto.getVehicleLine())
                .vehicleCal(prismDataInputDto.getCalibR())
                .wersNotice(prismDataInputDto.getWersNtcR())
                .build();
    }

    @Override
    public List<FirmwareDetailsResponse> fetchFirmwareDetailsBasedOnReleaseType(String releaseType) {
        List<Firmware> firmwares = firmwareRepository.findFirmwaresByReleaseType(releaseType);

        if (firmwares.isEmpty()) {
            throw new ResourceNotFoundException("No records found.");
        }

        return firmwares.stream().map(firmware -> {
            List<UserRoleDto> userRoles = userRoleRepository.findUserRolesByFirmwareKey(firmware.getFirmwareK());

            if (userRoles != null && !userRoles.isEmpty()) {
                // Update supplier name to "All Suppliers" if it's null or empty
                userRoles.forEach(userRole -> {
                    if (userRole.getSupplierName() == null || userRole.getSupplierName().isEmpty()) {
                        userRole.setSupplierName("All Suppliers");
                    }
                });
            }

            return new FirmwareDetailsResponse(
                    firmware.getFirmwareN(),
                    firmware.getFirmwareX(),
                    firmware.getRevwRespC(),
                    userRoles);
        }).toList();
    }


    private List<PartFirmwareResponse> convertToPartFirmwareResponse(List<PartFirwareDto> partFirmwareDtos) {
        return partFirmwareDtos.stream().map(partFirwareDto -> new PartFirmwareResponse(
                partFirwareDto.getPartR(),
                partFirwareDto.getEngineerCdsidC(),
                partFirwareDto.getHardwarePartR(),
                partFirwareDto.getCoreHardwarePartR(),
                partFirwareDto.getMicroTypX(),
                programDescriptionRepository.fetchProgramDescriptionByPartNumber(partFirwareDto.getPartR()),
                partFirwareDto.getPartNumX())).toList();
    }


}
