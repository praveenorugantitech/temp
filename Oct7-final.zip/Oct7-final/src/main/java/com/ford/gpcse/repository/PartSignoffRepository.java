package com.ford.gpcse.repository;

import com.ford.gpcse.entity.PartSignoff;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PartSignoffRepository extends JpaRepository<PartSignoff, String> {

    @Modifying
    @Query("UPDATE PartSignoff ps SET ps.userCdsidC = " +
            "(SELECT p.engineerCdsidC FROM ps.part p WHERE p.partR = :partR) " +
            "WHERE ps.signoffTypC = :signoffType " +
            "AND ps.signoffS IS NULL")
    int updateUserCdsidCForSignoffs(@Param("signoffType") String signoffType,
                                    @Param("partR") String partR);

}
