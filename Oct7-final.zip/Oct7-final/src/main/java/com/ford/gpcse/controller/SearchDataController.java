package com.ford.gpcse.controller;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.*;
import com.ford.gpcse.service.SearchDataService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1_0/search")
@Tag(description = "Search based on Wers Concern, Wers Notice, Program, Part Number/Catchword/Date Range, Release Request Search, Production Part Number Search, Programs Search, Wers Text based on Wers Concern.", name = "Search Data")
public class SearchDataController {

    private final SearchDataService searchDataService;

    @LoggingAspect
    @TrackExecutionTime
    @GetMapping("/wers-concern/{wersConcern}")
    @Operation(description = "Wers Concern Search", summary = "Wers Concern Search")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully retrieved resource"), @ApiResponse(responseCode = "404", description = "Resource not found")})
    public List<FirmwareResponse> fetchFirmwareDetailsByWersConcern(@PathVariable String wersConcern) {
        return searchDataService.fetchFirmwareDetailsByWersConcern(wersConcern);
    }

    @LoggingAspect
    @TrackExecutionTime
    @GetMapping("/wers-notice/{wersNotice}")
    @Operation(description = "Wers Notice Search", summary = "Wers Notice Search")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully retrieved resource"), @ApiResponse(responseCode = "404", description = "Resource not found")})
    public List<FirmwareResponse> fetchFirmwareDetailsByWersNotice(@PathVariable String wersNotice) {
        return searchDataService.fetchFirmwareDetailsByWersNotice(wersNotice);
    }

    @LoggingAspect
    @TrackExecutionTime
    @PostMapping("/programs")
    @Operation(description = "Program Search", summary = "Program Search")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully retrieved resource"), @ApiResponse(responseCode = "404", description = "Resource not found")})
    public List<FirmwareResponse> fetchFirmwareDetailsByPrograms(@RequestBody List<Long> programKeys) {
        return searchDataService.fetchFirmwareDetailsByPrograms(programKeys);
    }

    @LoggingAspect
    @TrackExecutionTime
    @PostMapping("/part-number")
    @Operation(description = "Part Number/Catchword/Date Range Search", summary = "Part Number/Catchword/Date Range Search")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully retrieved resource"), @ApiResponse(responseCode = "404", description = "Resource not found")})
    public List<PartNumberSearchResponse> fetchFirmwareDetailsByPartNumber(@RequestBody PartNumberSearchRequest partNumberSearchRequest) {
        return searchDataService.fetchFirmwareDetailsByPartNumber(partNumberSearchRequest);
    }

    @LoggingAspect
    @TrackExecutionTime
    @PostMapping("/release-request")
    @Operation(description = "Release Request Search", summary = "Release Request Search")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Successfully retrieved resource"), @ApiResponse(responseCode = "404", description = "Resource not found")})
    public List<ReleaseRequest> fetchReleaseRequests(ReleaseRequestSearchInput releaseRequestSearchInput) {
        return searchDataService.fetchReleaseRequests(releaseRequestSearchInput);
    }

    @TrackExecutionTime
    @LoggingAspect
    @PostMapping(value = "/production-part-number")
    @Operation(
            summary = "Production Part Number Search",
            description = "Production Part Number Search"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public ResponseEntity<List<ProductionPartNumberSearchResponse>> fetchProductionPartNumber(@RequestBody ProductionPartNumberSearchRequest productionPartNumberSearchRequest) {
        return ResponseEntity.ok(searchDataService.fetchProductionPartNumber(productionPartNumberSearchRequest));
    }

    @TrackExecutionTime
    @LoggingAspect
    @GetMapping(value = "/wers-text/wers-concern/{wersConcern}")
    @Operation(
            summary = "Wers Text Based on Wers Concern Search",
            description = "Wers Text Based on Wers Concern Search"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public ResponseEntity<String> fetchWersTextByConcern(@PathVariable("wersConcern") String wersConcern) {
        return ResponseEntity.ok(searchDataService.fetchWersTextByConcern(wersConcern));
    }


}