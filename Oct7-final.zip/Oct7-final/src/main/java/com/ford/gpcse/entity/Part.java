package com.ford.gpcse.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR01_PART")
public class Part {
    @Id
    @Column(name = "PCMR01_PART_R", nullable = false, length = 24)
    private String partR;

    @Column(name = "PCMR01_IPF_PART_R", length = 24)
    private String ipfPartR;

    @Column(name = "PCMR01_REPLACED_PART_R", length = 24)
    private String replacedPartR;

    @Column(name = "PCMR01_PARNT_PART_R", length = 24)
    private String parntPartR;
    @ManyToOne
    @JoinColumn(name = "PCMR08_CATCHWORD_C", referencedColumnName = "PCMR08_CATCHWORD_C")
    private Catchword catchword;

    @ManyToOne
    @JoinColumn(name = "PCMR08_CATCHWORD_TYP_C", referencedColumnName = "PCMR08_CATCHWORD_TYP_C")
    private Catchword catchwordType;

    @ManyToOne
    @JoinColumn(name = "PCMR14_MODULE_TYP_C", referencedColumnName = "PCMR14_MODULE_TYP_C")
    private ModuleType moduleType;

    @ManyToOne
    @JoinColumn(name = "PCMR15_REL_TYP_C", referencedColumnName = "PCMR15_REL_TYP_C")
    private ReleaseType releaseType;

    @ManyToOne
    @JoinColumn(name = "PCMR17_SUPL_C", referencedColumnName = "PCMR17_SUPL_C")
    private Supplier supplier;

    @ManyToOne
    @JoinColumn(name = "PCMR19_MICRO_TYP_C", referencedColumnName = "PCMR19_MICRO_TYP_C")
    private MicroType microType;

    @ManyToOne
    @JoinColumn(name = "PCMR24_REL_USG_C", referencedColumnName = "PCMR24_REL_USG_C")
    private RelUsg releaseUsage;
    @ManyToOne
    @JoinColumn(name = "PCMR26_BACKWARD_COMPAT_C", referencedColumnName = "PCMR26_BACKWARD_COMPAT_C")
    private BackwardCompat backwardCompat;

    @ManyToOne
    @JoinColumn(name = "PCMR39_LABEL_USG_K", referencedColumnName = "PCMR39_LABEL_USG_K")
    private LabelUsg labelUsage;

    @ManyToOne
    @JoinColumn(name = "PCMR40_RGN_BUILT_C", referencedColumnName = "PCMR40_RGN_BUILT_C")
    private RgnBuilt regionBuilt;

    @Column(name = "PCMR01_PRODN_F")
    private String prodnF;

    @Column(name = "PCMR01_ARCH_F")
    private String archF;

    @Column(name = "PCMR01_SALEABLE_F")
    private String saleableF;

    @Column(name = "PCMR01_INDSTR_COST_A", precision = 19, scale = 4)
    private BigDecimal indstrCostA;

    @Column(name = "PCMR01_VEH_LVL_COORD_F")
    private String vehLvlCoordF;

    @Column(name = "PCMR01_CATCHWORD_C")
    private String catchWordC;

    @Column(name = "PCMR01_PART_NUM_X")
    private String partNumX;

    @Column(name = "PCMR01_ENGINEER_CDSID_C")
    private String engineerCdsidC;
    @Column(name = "PCMR01_STRAT_REL_C")
    private String stratRelC;

    @Column(name = "PCMR01_CALIB_R")
    private String calibR;

    @Column(name = "PCMR01_CONCERN_C")
    private String concernC;

    @Column(name = "PCMR01_CONCERN_Y")
    private String concernY;

    @Column(name = "PCMR01_CMT_X")
    private String cmtX;

    @Column(name = "PCMR01_STAT_C")
    private String statC;

    @Column(name = "PCMR01_RELD_F")
    private String reldF;

    @Column(name = "PCMR01_RELD_Y")
    private LocalDate reldY;

    @Column(name = "PCMR01_CHIP_D")
    private String chipD;

    @Column(name = "PCMR01_HARDWARE_PART_R")
    private String hardwarePartR;

    @Column(name = "PCMR01_STRAT_CALIB_PART_R")
    private String stratCalibPartR;

    @Column(name = "PCMR01_STRAT_PART_R")
    private String stratPartR;

    @Column(name = "PCMR01_CALIB_PART_R")
    private String calibPartR;

    @Column(name = "PCMR01_WERS_NTC_R")
    private String wersNtcR;

    @Column(name = "PCMR01_HCR_R")
    private String hcrR;
    @Column(name = "PCMR01_SVC_MODULE_PART_R")
    private String svcModulePartR;

    @Column(name = "PCMR01_SVC_MODULE_F")
    private String svcModuleF;

    @Column(name = "PCMR01_PWRTRN_CALIB_CDSID_C")
    private String pwrtrnCalibCdsidC;

    @Column(name = "PCMR01_SW_REL_ANLST_CDSID_C")
    private String swRelAnlstCdsidC;

    @Column(name = "PCMR01_SW_DV_MODULE_REQR_F")
    private String swDvModuleReqrF;

    @Column(name = "PCMR01_CVN_C")
    private String cvnC;

    @Column(name = "PCMR01_BACKWARD_COMPAT_GRP_C")
    private String backwardCompatGrpC;

    @Column(name = "PCMR01_PROC_CMT_X")
    private String procCmtX;

    @Column(name = "PCMR01_SYMPTOM_CMT_X")
    private String symptomCmtX;

    @Column(name = "PCMR01_PROJ_CTL_ENG_CDSID_C")
    private String projCtlEngCdsidC;

    @Column(name = "PCMR01_CHECKSUM_C")
    private String checksumC;

    @Column(name = "PCMR01_BLD_LVL_C")
    private String bldLvlC;

    @Column(name = "PCMR01_PRTY_C")
    private String prtyC;

    @Column(name = "PCMR01_PRTY_DTL_X")
    private String prtyDtlX;

    @Column(name = "PCMR01_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR01_CREATE_S", nullable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR01_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR01_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    @Column(name = "PCMR01_OTA_F")
    private String otaF;

    @Column(name = "PCMR01_HMLGN_F")
    private String hmlgnF;

    @Column(name = "PCMR01_ALERT_BNCH_FLASH_F")
    private String alertBnchFlashF;

    @Column(name = "PCMR01_ALERT_REQR_ONSITE_MOD_F")
    private String alertReqrOnsiteModF;

    @Column(name = "PCMR01_ALERT_REQR_USE_PPM_F")
    private String alertReqrUsePpmF;

    @Column(name = "PCMR01_PLN_EFF_Y")
    private Date plnEffY;

    @Column(name = "PCMR01_DOMAIN_N")
    private String domainN;

    @Column(name = "PCMR01_DOMAIN_INSTNC_N")
    private String domainInstncN;

    @Column(name = "PCMR01_VEH_CAN_TYP_C")
    private String vehCanTypC;
    @Column(name = "PCMR01_CFX_REL_TGT_Y")
    private Date cfxRelTgtY;

    @Column(name = "PCMR01_CORE_HARDWARE_PART_R")
    private String coreHardwarePartR;

    @Column(name = "PCMR01_CORE_HARDWARE_CDSID_C")
    private String coreHardwareCdsidC;

    @Column(name = "PCMR01_SW_DL_SPEC_R")
    private String swDlSpecR;

    @Column(name = "PCMR01_GEN_GLBL_SPEC_R")
    private String genGlblSpecR;

    @Column(name = "PCMR01_DOMAIN_INSTNC_VER_R")
    private String domainInstncVerR;

    @Column(name = "PCMR01_APP_INSTNC_N")
    private String appInstncN;

    @Column(name = "PCMR01_APP_INSTNC_VER_R")
    private String appInstncVerR;

    @Column(name = "PCMR01_REUSE_SW_F")
    private String reuseSwF;

    @Column(name = "PCMR01_STRAT_BUILD_COMP_F")
    private String stratBuildCompF;

    @PrePersist
    public void prePersist() {
        this.alertReqrOnsiteModF = "N";
        this.alertBnchFlashF = "N";
        this.reldF = "N";
        this.prodnF = "Y";
        this.archF = "N";
        this.alertReqrUsePpmF = "N";
        this.hmlgnF = "N";
        this.indstrCostA = BigDecimal.ZERO;
        this.otaF = "N";
        this.reuseSwF = "N";
        this.saleableF = "N";
        this.stratBuildCompF = "N";
        this.svcModuleF = "N";
        this.swDvModuleReqrF = "N";
        this.vehLvlCoordF = "N";
    }
}