package com.ford.gpcse.repository;

import com.ford.gpcse.entity.Firmware;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FirmwareRepository extends JpaRepository<Firmware, Long> {

    @Query("SELECT pf.fileN FROM PartFirmware pf " +
            "JOIN pf.firmware fw " +
            "WHERE fw.firmwareN LIKE :firmwareNameLike " +
            "AND pf.part.partR = :partR")
    String fetchFileN(@Param("partR") String partNumber, @Param("firmwareNameLike") String firmwareNameLike);


    @Query("SELECT f FROM Firmware f WHERE f.mutualExclusiveGrpR > 0 " +
            "AND f.firmwareK IN (SELECT r.firmware.firmwareK FROM ReleaseTypeFirmware r WHERE r.releaseType.relTypC = :releaseType) " +
            "ORDER BY f.sortOrdR, f.firmwareN")
    List<Firmware> findFirmwaresByReleaseType(@Param("releaseType") String releaseType);



}
