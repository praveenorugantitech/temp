package com.ford.gpcse.repository;

import com.ford.gpcse.entity.ModuleName;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ModuleNameRepository extends JpaRepository<ModuleName, String> {
    @Query("SELECT m.moduleN FROM ModuleName m WHERE m.actvF = 'Y' ORDER BY m.sortOrdR, m.moduleN")
    List<String> findActiveModuleNames();
}
