package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR17_SUPL")
public class Supplier {

    @Id
    @Column(name = "PCMR17_SUPL_C")
    private String suplC;
    @Column(name = "PCMR17_SUPL_X")
    private String suplX;

    @Column(name = "PCMR17_ARCH_F")
    private String archF;


    @Column(name = "PCMR17_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR17_CREATE_S", nullable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR17_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR17_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;


}
