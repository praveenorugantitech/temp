package com.ford.gpcse.controller;


import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.*;
import com.ford.gpcse.service.NewMainMicroTypeService;
import com.ford.gpcse.service.Part2PdxService;
import com.ford.gpcse.service.SblService;
import com.ford.gpcse.service.impl.PblServiceImpl;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1_0")
@Tag(description = "Procedures Operations include Calibration Engineer, Release Engineer, Software Release Analyst, Request New Main Micro Type, Add New Part 2 or PDX, Add New PBL, Add New SBL.", name = "Procedures Operations")
public class ProceduresOperationsController {

    private final SblService sblService;
    private final PblServiceImpl pblService;
    private final NewMainMicroTypeService newMainMicroTypeService;
    private final Part2PdxService part2PdxService;


    @TrackExecutionTime
    @LoggingAspect
    @PostMapping("/sbl")
    @Operation(description = "Add New SBL", summary = "Add New SBL")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<String> createSbl(@RequestBody CreateSblRequest createSblRequest) {
        sblService.createSbl(createSblRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body("Part request has been submitted.");
    }

    @TrackExecutionTime
    @LoggingAspect
    @PutMapping("/sbl")
    @Operation(description = "Replace existing SBL", summary = "Replace existing SBL")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<String> replaceSbl(@RequestBody ReplaceSblRequest replaceSblRequest) {
        sblService.replaceSbl(replaceSblRequest);
        return ResponseEntity.ok().body("Part request has been submitted.");
    }

    @TrackExecutionTime
    @LoggingAspect
    @PostMapping(value = "/pbl")
    @Operation(description = "Add New PBL", summary = "Add New PBL")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<String> createPbl(@RequestBody CreatePblRequest createPblRequest) {
        pblService.createPbl(createPblRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(createPblRequest.getNewPbl() + " has been added to the firmware drop down list");

    }

    @TrackExecutionTime
    @LoggingAspect
    @PutMapping(value = "/pbl")
    @Operation(description = "Replace existing PBL", summary = "Replace existing PBL")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<String> replacePbl(@RequestBody ReplacePblRequest replacePblRequest) {
        pblService.replacePbl(replacePblRequest);
        return ResponseEntity.ok(replacePblRequest.getNewPbl() + " has been added to the firmware drop down list");
    }

    @TrackExecutionTime
    @LoggingAspect
    @GetMapping(value = "/pbl/findPartsByFirmware")
    @Operation(description = "Find Parts By Firmware Based on Current and Replace Pbl", summary = "Find Parts By Firmware Based on Current and Replace Pbl")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public ResponseEntity<List<PartFirmwareResponse>> findPartsByFirmware(@RequestBody ReplacePblRequest replacePblRequest) {
        return ResponseEntity.ok(pblService.findPartsByFirmware(replacePblRequest));
    }

    @PostMapping("/main-micro-type")
    @Operation(description = "Request New Main Micro Type", summary = "Request New Main Micro Type")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    void addNewMainMicroType(NewMicroMicroTypeRequest newMicroMicroTypeRequest) {
        newMainMicroTypeService.addNewMainMicroType(newMicroMicroTypeRequest);
    }

    @TrackExecutionTime
    @LoggingAspect
    @PostMapping("/part2-pdx")
    @Operation(description = "Add New Par2 or Pdx", summary = "Add New Par2 or Pdx")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<String> addNewPart2OrPdx(@RequestBody Part2PdxRequest part2PdxRequest) {
        String response = part2PdxService.addNewPart2OrPdx(part2PdxRequest);
        return ResponseEntity.ok(response);
    }
}
