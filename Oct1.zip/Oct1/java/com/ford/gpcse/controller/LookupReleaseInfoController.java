package com.ford.gpcse.controller;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.*;
import com.ford.gpcse.entity.ReleaseRequest;
import com.ford.gpcse.service.LookupReleaseInfoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1_0/lookup/release-info")
@Tag(description = "Lookup Release Info Operations include Concern/Notice and Advanced Search include Release Status, Program, Concern/Notice, Part Number/Catchword/Date Range, Release Request", name = "Lookup Release Info Operations")
@RequiredArgsConstructor
@Slf4j
public class LookupReleaseInfoController {

    private final LookupReleaseInfoService lookupReleaseInfoService;

    @LoggingAspect
    @TrackExecutionTime
    @GetMapping("/wers-concern/{wersConcern}")
    @Operation(description = "Wers Concern Search", summary = "Wers Concern Search")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<FirmwareResponse> fetchFirmwareDetailsByWersConcern(@PathVariable String wersConcern) {
        return lookupReleaseInfoService.fetchFirmwareDetailsByWersConcern(wersConcern);
    }

    @LoggingAspect
    @TrackExecutionTime
    @GetMapping("/wers-notice/{wersNotice}")
    @Operation(description = "Wers Notice Search", summary = "Wers Notice Search")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<FirmwareResponse> fetchFirmwareDetailsByWersNotice(@PathVariable String wersNotice) {
        return lookupReleaseInfoService.fetchFirmwareDetailsByWersNotice(wersNotice);
    }

    @LoggingAspect
    @TrackExecutionTime
    @PostMapping("/programs")
    @Operation(description = "Program Search", summary = "Program Search")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<FirmwareResponse> fetchFirmwareDetailsByPrograms(@RequestBody ProgramSearchRequest programSearchRequest) {
        return lookupReleaseInfoService.fetchFirmwareDetailsByPrograms(programSearchRequest.getPrograms());
    }

    @LoggingAspect
    @TrackExecutionTime
    @GetMapping("/release-status")
    @Operation(description = "Release Status Search", summary = "Release Status Search")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<ReleaseStatusSearchResponse> fetchReleaseStatusDetails() {
        return lookupReleaseInfoService.fetchReleaseStatusDetails();
    }

    @LoggingAspect
    @TrackExecutionTime
    @PostMapping("/part-number")
    @Operation(description = "Part Number/Catchword/Date Range Search", summary = "Part Number/Catchword/Date Range Search")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<PartNumberSearchResponse> fetchFirmwareDetailsByPartNumber(@RequestBody PartNumberSearchRequest partNumberSearchRequest) {
        return lookupReleaseInfoService.fetchFirmwareDetailsByPartNumber(partNumberSearchRequest);
    }

    @LoggingAspect
    @TrackExecutionTime
    @PostMapping("/release-request")
    @Operation(description = "Release Request Search", summary = "Release Request Search")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found")
    })
    public List<ReleaseRequest> fetchReleaseRequests(ReleaseRequestSearchInput releaseRequestSearchInput) {
        return lookupReleaseInfoService.fetchReleaseRequests(releaseRequestSearchInput);
    }

}
