package com.ford.gpcse.service;

import com.ford.gpcse.bo.*;
import com.ford.gpcse.entity.ReleaseRequest;

import java.util.List;

public interface LookupReleaseInfoService {

    List<FirmwareResponse> fetchFirmwareDetailsByWersConcern(String wersConcern);

    List<FirmwareResponse> fetchFirmwareDetailsByWersNotice(String wersNotice);

    List<FirmwareResponse> fetchFirmwareDetailsByPrograms(List<String> programs);

    List<ReleaseStatusSearchResponse> fetchReleaseStatusDetails();

    List<PartNumberSearchResponse> fetchFirmwareDetailsByPartNumber(PartNumberSearchRequest partNumberSearchRequest);

    List<ReleaseRequest> fetchReleaseRequests(ReleaseRequestSearchInput releaseRequestSearchInput);
}
