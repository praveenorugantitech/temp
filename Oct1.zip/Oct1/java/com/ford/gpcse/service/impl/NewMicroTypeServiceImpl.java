package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.NewMicroMicroTypeRequest;
import com.ford.gpcse.entity.*;
import com.ford.gpcse.exception.MicroTypeAlreadyRequestedException;
import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.model.Email;
import com.ford.gpcse.repository.MicroTypeRepository;
import com.ford.gpcse.repository.SignoffMicroTypeRepository;
import com.ford.gpcse.service.NewMainMicroTypeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class NewMicroTypeServiceImpl implements NewMainMicroTypeService {

    private final MicroTypeRepository microTypeRepository;
    private final SignoffMicroTypeRepository signoffMicroTypeRepository;
    private final EmailService emailService;


    @Override
    public void addNewMainMicroType(NewMicroMicroTypeRequest newMicroMicroTypeRequest) {

        // Check if the main micro type name exists
        int count = microTypeRepository.countByMicroTypeName(newMicroMicroTypeRequest.getMainMicroTypeName());

        if (count > 0) {
            throw new MicroTypeAlreadyRequestedException(newMicroMicroTypeRequest.getMainMicroTypeName());
        }

        int microId = microTypeRepository.fetchMicroId();

        MicroType microType = MicroType.builder().microTypC((long) microId)
                .microTypX(newMicroMicroTypeRequest.getMainMicroTypeName())
                .microTypOwnrCdsidC(newMicroMicroTypeRequest.getCreateUser())
                .createUserC(newMicroMicroTypeRequest.getCreateUser())
                .lastUpdtUserC(newMicroMicroTypeRequest.getLastUpdateUser())
                .moduleType(ModuleType.builder().moduleTypC(newMicroMicroTypeRequest.getModuleTypeCode()).build())
                .supplier(Supplier.builder().suplC(newMicroMicroTypeRequest.getSupplierCode()).build())
                .build();

        microTypeRepository.save(microType);

        // sign off
        SignoffMicroType signoffMicroType = SignoffMicroType.builder()
                .id(SignoffMicroTypeId.builder().signoffTypC("MMSUP").microTypC((long) microId).build())
                .createUserC(newMicroMicroTypeRequest.getCreateUser())
                .lastUpdtUserC(newMicroMicroTypeRequest.getLastUpdateUser())
                .build();

        signoffMicroTypeRepository.save(signoffMicroType);

        String url = "";
        String baseUrl = "";
        String emailTo = "";


        emailService.sendMail(Email.builder().subject("Release action required (Main Micro Supplier Review)")
                .to(List.of())
                .from("")
                .body("<body><p>" + newMicroMicroTypeRequest.getCreateUser() + " has requested a new " + newMicroMicroTypeRequest.getModuleTypeCode() + " Main Micro Type '" + newMicroMicroTypeRequest.getMainMicroTypeName() + "' for " + newMicroMicroTypeRequest.getSupplierName() + ". Please use the link provided to review this request.</p><p><a href=\"" + baseUrl + url + "?MicroId=" + microId + "\">" + baseUrl + url + "?MicroId=" + microId + "</a></p><p>&nbsp;</p></body>").build());

        // write off
        signoffMicroTypeRepository.updateSignoff("MMSUP", String.valueOf(microId));
    }
}
