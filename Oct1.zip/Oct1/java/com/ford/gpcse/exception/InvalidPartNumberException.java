package com.ford.gpcse.exception;

public class InvalidPartNumberException extends RuntimeException {
    public InvalidPartNumberException(String partNumber) {
        super("Invalid part number " + partNumber + ".  Part number has already been used.");
    }
}