package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class PartNumberSearchResponse {
    private String assemblyPN;
    private String hardwarePN;
    private String supplier;
    private String catchWord;
    private String calibration;
    private String status;
    private String dateCreated;
}
