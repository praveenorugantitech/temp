package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
public class ReleaseRequestSearchInput {
    private String id;
    private String moduleTypeCode;
    private String calibrationLevel;
    private String status;
    private String owner;
    private String modelYear;
    private String program;
    private String engine;
    private String createUser;
    private String lastUpdateUser;
}
