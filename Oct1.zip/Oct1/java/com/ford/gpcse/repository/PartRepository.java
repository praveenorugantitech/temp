package com.ford.gpcse.repository;

import com.ford.gpcse.dto.*;
import com.ford.gpcse.entity.Part;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface PartRepository extends JpaRepository<Part, String>, JpaSpecificationExecutor<Part> {

    @Query("SELECT new com.ford.gpcse.dto.ReplaceSblPartDetailsDto(p.moduleType.moduleTypC, "
            + "p.microType.microTypC, p.supplier.suplC, "
            + "(SELECT COUNT(sub) FROM Part sub WHERE sub.partR = :newPartNumber)) "
            + "FROM Part p WHERE p.partR = :oldPartNumber")
    List<ReplaceSblPartDetailsDto> findPartDetails(@Param("oldPartNumber") String oldPartNumber,
                                                   @Param("newPartNumber") String newPartNumber);

    @Query("SELECT new com.ford.gpcse.dto.PartFirwareDto(p.partR, p.partNumX, p.calibPartR, p.stratRelC, "
            + "p.engineerCdsidC, p.hardwarePartR, mt.microTypX, p.chipD, p.stratCalibPartR, p.catchWordC, "
            + "p.releaseUsage, p.releaseType, p.stratPartR, p.cmtX, p.coreHardwarePartR, p.concernC) "
            + "FROM Part p " + "JOIN p.moduleType m " + "LEFT JOIN p.microType mt "
            + "WHERE p.releaseType IN :hardwareReleaseTypes "
            + "AND p.partR IN (SELECT pf.partR FROM PartFirmware pf WHERE pf.fileN = :mNewPbl) "
            + "AND p.reldF = 'Y' " + "ORDER BY mt.microTypX, p.hardwarePartR")
    List<PartFirwareDto> findPartsByFirmware(@Param("mNewPbl") String mNewPbl,
                                             @Param("hardwareReleaseTypes") List<String> hardwareReleaseTypes);

    @Query("SELECT new com.ford.gpcse.dto.FirmwareDto(p.partR, p.partNumX, p.calibPartR, p.stratRelC, "
            + "p.engineerCdsidC, p.hardwarePartR, mt.microTypX, p.chipD, p.stratCalibPartR, p.catchWordC, "
            + "ru.relUsgX, r.relTypX, p.wersNtcR, p.concernC, p.cmtX, p.pwrtrnCalibCdsidC, "
            + "s.suplX, p.coreHardwareCdsidC, p.coreHardwarePartR) " + "FROM Part p " + "JOIN p.releaseType r " + "JOIN p.releaseUsage ru " + "JOIN p.moduleType m "
            + "LEFT JOIN p.microType mt " + "LEFT JOIN p.supplier s " + "WHERE p.statC IS NOT NULL "
            + "AND p.concernC = :wersConcern " + "ORDER BY r.relTypX, ru.relUsgX, p.concernC DESC, p.cmtX, p.partR")
    List<FirmwareDto> fetchFirmwareDetailsByWersConcern(@Param("wersConcern") String wersConcern);

    @Query("SELECT new com.ford.gpcse.dto.FirmwareDto(p.partR, p.partNumX, p.calibPartR, p.stratRelC, "
            + "p.engineerCdsidC, p.hardwarePartR, mt.microTypX, p.chipD, p.stratCalibPartR, p.catchWordC, "
            + "ru.relUsgX, r.relTypX, p.wersNtcR, p.concernC, p.cmtX, p.pwrtrnCalibCdsidC, "
            + "s.suplX, p.coreHardwareCdsidC, p.coreHardwarePartR) " + "FROM Part p " + "JOIN p.releaseType r " + "JOIN p.releaseUsage ru " + "JOIN p.moduleType m "
            + "LEFT JOIN p.microType mt " + "LEFT JOIN p.supplier s " + "WHERE p.statC IS NOT NULL "
            + "AND p.wersNtcR LIKE :wersNotice "
            + "ORDER BY r.relTypX, ru.relUsgX, p.concernC DESC, p.cmtX, p.partR")
    List<FirmwareDto> findFirmwareDetailsByWersNotice(@Param("wersNotice") String wersNotice);


    @Query("SELECT new com.ford.gpcse.dto.FirmwareDto(tblSoftRel.partR, tblSoftRel.partNumX, " +
            "tblSoftRel.calibR, tblSoftRel.stratRelC, tblSoftRel.engineerCdsidC, " +
            "tblSoftRel.hardwarePartR, tblMM.microTypX, tblSoftRel.chipD, " +
            "tblSoftRel.stratCalibPartR, tblSoftRel.catchWordC, ru.relUsgC, " +
            "rt.relTypC, tblSoftRel.wersNtcR, tblSoftRel.concernC, " +
            "tblSoftRel.cmtX, tblSoftRel.pwrtrnCalibCdsidC, tblSup.suplX, tblMM.microTypOwnrCdsidC, " +
            "tblSoftRel.coreHardwarePartR) " +
            "FROM Part tblSoftRel " +
            "INNER JOIN tblSoftRel.moduleType tblModType " +
            "LEFT JOIN tblSoftRel.microType tblMM " +
            "LEFT JOIN tblSoftRel.supplier tblSup " +
            "LEFT JOIN tblSoftRel.releaseUsage ru " +
            "LEFT JOIN tblSoftRel.releaseType rt " +
            "WHERE tblSoftRel.statC IS NOT NULL " +
            "AND tblSoftRel.partR IN ( " +
            "SELECT tblProgramPart.part.partR " +
            "FROM ProgramDescription tblProgramDesc " +
            "INNER JOIN ProgramPart  tblProgramPart " +
            "ON tblProgramDesc.pgmK = tblProgramPart.pgmK "+
            "WHERE tblProgramDesc.pgmK IN :programKeys OR tblProgramDesc.pgmK = -999998) " +
            "ORDER BY rt.relTypC, ru.relUsgC, tblSoftRel.concernC DESC, tblSoftRel.cmtX, tblSoftRel.partR")
    List<FirmwareDto> fetchFirmwareDetailsByPrograms(@Param("programKeys") List<String> programKeys);

    @Query("SELECT DISTINCT  new com.ford.gpcse.dto.ReleaseStatusDto(p.concernC, p.partR, p.statC, m.moduleTypX, r.relTypX, p.concernY)" + "FROM Part p "
            + "JOIN p.supplier sup " + "JOIN p.moduleType m " + "JOIN p.releaseType r " + "WHERE p.archF = 'N' "
            + "AND r.relTypC NOT IN ('HRDCN', 'HWPUT', 'VCMHC') " + "AND p.statC NOT IN ('NewPnRequest', 'Complete') "
            + "ORDER BY p.concernC DESC, p.partR")
    List<ReleaseStatusDto> findReleaseStatusDetails();

    @Modifying
    @Query("UPDATE Part p " +
            "SET p.statC = 'HardLock', " +
            "p.stratCalibPartR = p.partR, " +
            "p.wersNtcR = :wersNtcR " +
            "WHERE p.partR = :partR")
    int updatePartStatusAndCalib(@Param("wersNtcR") String wersNtcR,
                                 @Param("partR") String partR);

    @Query("SELECT new com.ford.gpcse.dto.HardwareEmailPartDto(p.partR, p.engineerCdsidC, p.hardwarePartR, p.coreHardwarePartR, m.microTypX) " +
            "FROM Part p " +
            "JOIN p.microType m " +
            "WHERE p.reldF = 'Y' " +
            "AND p.partR IN :partNumbers " +
            "ORDER BY p.partR")
    List<HardwareEmailPartDto> findPartsForEmail(@Param("partNumbers") List<String> partNumbers);

    @Query("SELECT COUNT(p) FROM Part p WHERE p.partR = :partNumber")
    int countByPartNumber(@Param("partNumber") String partNumber);
}