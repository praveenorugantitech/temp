package com.ford.gpcse.repository;

import com.ford.gpcse.dto.LookupProgramDescriptionDto;
import com.ford.gpcse.dto.ProgramDescriptionDto;
import com.ford.gpcse.dto.WersTextPartDescriptionDto;
import com.ford.gpcse.entity.ProgramDescription;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProgramDescriptionRepository extends JpaRepository<ProgramDescription, Long>, JpaSpecificationExecutor<ProgramDescription> {


    @Query("SELECT new com.ford.gpcse.dto.LookupProgramDescriptionDto(pd.pgmK, pd.mdlYrR, pd.pgmN, pd.platN, pd.engN, pd.transN) " +
            "FROM ProgramDescription pd " +
            "JOIN ProgramPart pp ON pd.pgmK = pp.pgmK " +
            "WHERE pp.part.partR = :partR")
    List<LookupProgramDescriptionDto> fetchProgramDescriptionByPartNumber(@Param("partR") String partR);


    @Query("SELECT DISTINCT new com.ford.gpcse.dto.ProgramDescriptionDto(pd.pgmK, pd.mdlYrR, pd.pgmN, pd.platN, pd.engN, pd.transN) " +
            "FROM ProgramDescription pd JOIN ProgramPart pp ON pd.pgmK = pp.pgmK " +
            "JOIN pp.part p " +
            "WHERE p.archF = 'N' AND p.reldF = 'Y' " +
            "ORDER BY pd.mdlYrR DESC, pd.pgmN, pd.platN, pd.engN, pd.transN")
    List<ProgramDescriptionDto> fetchDistinctPrograms();


    @Query("SELECT DISTINCT new com.ford.gpcse.dto.WersTextPartDescriptionDto(" +
            "pd.pgmK, pd.mdlYrR, pd.pgmN, pd.platN, pd.engN, pd.transN) " +
            "FROM ProgramDescription pd " +
            "JOIN ProgramPart pp ON pd.pgmK = pp.pgmK " +
            "WHERE " + "pp.part.partR IN :partNumbers " +
            "ORDER BY pd.mdlYrR, pd.pgmN, pd.platN, pd.engN")
    List<WersTextPartDescriptionDto> fetchPartsWithProgramDescription(@Param("partNumbers") List<String> partNumbers);

    @Query("SELECT DISTINCT pd.mdlYrR, pd.pgmN " +
            "FROM ProgramDescription pd " +
            "JOIN ProgramPart pp ON pd.pgmK = pp.pgmK " +
            "JOIN Part p ON pp.part.partR = p.partR " +
            "WHERE p.archF = 'N' " +
            "AND p.reldF = 'Y' " +
            "AND pd.mdlYrR > '2019' " +
            "ORDER BY pd.mdlYrR DESC, pd.pgmN")
    List<Object[]> fetchAllProgramsWhichHasPartNumber();

}
