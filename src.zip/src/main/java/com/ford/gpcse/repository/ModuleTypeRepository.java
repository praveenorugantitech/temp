package com.ford.gpcse.repository;

import com.ford.gpcse.entity.ModuleType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ModuleTypeRepository extends JpaRepository<ModuleType, String> {

    @Query("SELECT m FROM ModuleType m WHERE m.archF = 'N' ORDER BY m.sortOrdR, m.moduleTypC")
    List<ModuleType> fetchActiveModuleTypes();
}
