package com.ford.gpcse.repository;

import com.ford.gpcse.entity.ReleaseType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReleaseTypeRepository extends JpaRepository<ReleaseType, String> {

    @Query("SELECT rt FROM ReleaseType rt WHERE rt.archF = 'N' ORDER BY rt.sortOrdR")
    List<ReleaseType> fetchActiveReleaseTypes();
}
