package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExportFirwareXmlRequest {
    private List<String> partR;
    private String concernC;
    private String wersNtcR;
    private String fileName;
    private String exportVersion;
    private String createUser;
}
