package com.ford.gpcse.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReleaseStatus {
    private String concern;
    private String assemblyPN;
    private String releaseType;
    private String status;
    private String dateCreated;
}
