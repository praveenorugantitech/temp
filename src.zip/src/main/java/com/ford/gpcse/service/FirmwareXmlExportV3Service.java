package com.ford.gpcse.service;

import com.ford.gpcse.bo.ExportFirwareXmlRequest;
import org.springframework.core.io.Resource;

public interface FirmwareXmlExportV3Service {
    Resource generateFirmwareV3Xml(ExportFirwareXmlRequest exportFirwareXmlRequest);
}
