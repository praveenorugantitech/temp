package com.ford.gpcse.exception;

public class FirmwareAlreadyRequestedException extends RuntimeException {
    public FirmwareAlreadyRequestedException(String firmwareItemX) {
        super("Error: Firmware " + firmwareItemX + " has already been requested.");
    }
}