package com.ford.gpcse.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMS01_PGM_DESC")
public class ProgramDescription {

    @Id
    @Column(name = "PCMS01_PGM_K")
    private Long pgmK;


    @Column(name = "PCMS01_MDL_YR_R", nullable = false)
    private String mdlYrR;

    @Column(name = "PCMS01_PGM_N", nullable = false)
    private String pgmN;

    @Column(name = "PCMS01_ENG_N", nullable = false)
    private String engN;

    @Column(name = "PCMS01_TRANS_N", nullable = false)
    private String transN;

    @Column(name = "PCMS01_ARCH_F", nullable = false)
    private String archF;

    @Column(name = "PCMS01_PLAT_N", nullable = false)
    private String platN;

    @Column(name = "PCMS01_PGM_X", nullable = false)
    private String pgmX;

    @Column(name = "PCMS01_PCM_SRC_N", nullable = false)
    private String pcmSrcN;

    @Column(name = "PCMS01_OTH_ATTR_X", nullable = true)
    private String otherAttributes;

    @Column(name = "PCMS01_EMISSION_GRP_C", nullable = true)
    private String emissionGroupCode;

    @Column(name = "PCMS01_IVS_PGM_D", nullable = true)
    private String ivsProgramDate;

    @Column(name = "PCMS01_WERS_VEH_LN_C", nullable = true)
    private String wersVehicleLineCode;

    @Column(name = "PCMS01_WERS_EFF_PT_C", nullable = true)
    private String wersEffortPointCode;

    @Column(name = "PCMS01_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMS01_CREATE_S", nullable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMS01_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMS01_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;

    @Column(name = "PCMS01_PGM_STAT_C", nullable = false)
    private String programStatus;

    @Column(name = "PCMS01_OTA_F", nullable = true)
    private String otaF;
}
