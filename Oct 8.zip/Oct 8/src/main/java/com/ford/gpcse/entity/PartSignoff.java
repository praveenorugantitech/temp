package com.ford.gpcse.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR21_SIGNOFF_PART")
public class PartSignoff {

    @Id
    @Column(name = "PCMR20_SIGNOFF_TYP_C", length = 5)
    private String signoffTypC;

    @ManyToOne
    @JoinColumn(name = "PCMR01_PART_R", referencedColumnName = "PCMR01_PART_R")
    private Part part;

    @Column(name = "PCMR21_DEVIAT_F")
    private String deviatF;

    @Column(name = "PCMR21_SIGNOFF_S")
    private LocalDateTime signoffS;

    @Column(name = "PCMR21_USER_CDSID_C")
    private String userCdsidC;

    @Column(name = "PCMR21_REQT_Y")
    private LocalDate reqtY;

    @Column(name = "PCMR21_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR21_CREATE_S", nullable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR21_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR21_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;
}
