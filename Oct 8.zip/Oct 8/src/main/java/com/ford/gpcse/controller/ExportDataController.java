package com.ford.gpcse.controller;

import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.ExportFirwareXmlRequest;
import com.ford.gpcse.service.ExportDataService;
import com.ford.gpcse.util.DateFormatterUtility;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

@RestController
@RequiredArgsConstructor
@RequestMapping("/export")
@Tag(description = "Fetch Firmware Xml", name = "Export Data Operations")
public class ExportDataController {

    private final ExportDataService exportDataService;

    @TrackExecutionTime
    @LoggingAspect
    @PostMapping(value = "/firmware-xml")
    @Operation(
            summary = "Fetch Firmware xml",
            description = "Fetch Firmware xml"
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully Retrieved the Firmware Xml")
    })
    public ResponseEntity<Resource> fetchFirmareXml(@RequestBody ExportFirwareXmlRequest exportFirwareXmlRequest) {
        Resource resource = exportDataService.fetchFirmareXml(exportFirwareXmlRequest);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + "FirmwareExport" + DateFormatterUtility.dateTimeStringFormatFilename(LocalDateTime.now()) + ".xml")
                .header(HttpHeaders.CONTENT_TYPE, "application/xml")
                .body(resource);
    }


}
