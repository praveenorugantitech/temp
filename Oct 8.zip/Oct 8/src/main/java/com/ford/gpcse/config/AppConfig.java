package com.ford.gpcse.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "app")
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class AppConfig {

    private String vsemurl;
    private String oauthurl;
    private String clientid;
    private String clientsecret;
    private String resource;


}
