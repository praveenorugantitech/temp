package com.ford.gpcse.controller;


import com.ford.gpcse.aop.LoggingAspect;
import com.ford.gpcse.aop.TrackExecutionTime;
import com.ford.gpcse.bo.*;
import com.ford.gpcse.service.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1_0/procedures")
@Tag(description = "Edit Part, Request New Main Micro Type, Add New Part 2 or PDX, Add New PBL, Add New SBL.", name = "Procedures Operations")
public class ProceduresOperationsController {

    private final SblService sblService;
    private final PblService pblService;
    private final NewMainMicroTypeService newMainMicroTypeService;
    private final Part2PdxService part2PdxService;
    private final ProceduresOperationsService proceduresOperationsService;

    @TrackExecutionTime
    @LoggingAspect
    @PostMapping("/sbl")
    @Operation(
            summary = "Add New SBL Section - Add New SBL",
            description = "Endpoint to add a new SBL under the Add New SBL section."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<String> createSbl(@RequestBody CreateSblRequest createSblRequest) {
        sblService.createSbl(createSblRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body("Part request has been submitted.");
    }

    @TrackExecutionTime
    @LoggingAspect
    @PutMapping("/sbl")
    @Operation(
            summary = "Add New SBL Section - Replace Existing SBL",
            description = "Endpoint to replace an existing SBL under the Add New SBL section."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<String> replaceSbl(@RequestBody ReplaceSblRequest replaceSblRequest) {
        sblService.replaceSbl(replaceSblRequest);
        return ResponseEntity.ok().body("Part request has been submitted.");
    }

    @TrackExecutionTime
    @LoggingAspect
    @PostMapping(value = "/pbl")
    @Operation(
            summary = "Add New PBL Section - Add New PBL",
            description = "Endpoint to add a new PBL under the Add New PBL section."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<String> createPbl(@RequestBody CreatePblRequest createPblRequest) {
        pblService.createPbl(createPblRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(createPblRequest.getNewPbl() + " has been added to the firmware drop down list");

    }

    @TrackExecutionTime
    @LoggingAspect
    @PutMapping(value = "/pbl")
    @Operation(
            summary = "Add New PBL Section - Replace Existing PBL",
            description = "Endpoint to replace an existing PBL under the Add New PBL section."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<String> replacePbl(@RequestBody ReplacePblRequest replacePblRequest) {
        pblService.replacePbl(replacePblRequest);
        return ResponseEntity.ok(replacePblRequest.getNewPbl() + " has been added to the firmware drop down list");
    }

    @PostMapping("/main-micro-type")
    @Operation(
            summary = "Request New Main Micro Type Section - Request New Main Micro Type",
            description = "Endpoint to request a new main micro type under the Request New Main Micro Type section."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public void addNewMainMicroType(NewMicroMicroTypeRequest newMicroMicroTypeRequest) {
        newMainMicroTypeService.addNewMainMicroType(newMicroMicroTypeRequest);
    }

    @TrackExecutionTime
    @LoggingAspect
    @PostMapping("/part2-pdx")
    @Operation(
            summary = "Add New Par2 or Pdx Section - Add New Par2 or Pdx",
            description = "Endpoint to add a new Par2 or Pdx under the Add New Par2 or Pdx section."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<String> addNewPart2OrPdx(@RequestBody Part2PdxRequest part2PdxRequest) {
        String response = part2PdxService.addNewPart2OrPdx(part2PdxRequest);
        return ResponseEntity.ok(response);
    }

    @TrackExecutionTime
    @LoggingAspect
    @PutMapping("/part")
    @Operation(
            summary = "Software Release Analyst Section - Edit Part",
            description = "Enables editing of part by Software Release Analysts."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully created the resource"),
            @ApiResponse(responseCode = "404", description = "Resource not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request")
    })
    public ResponseEntity<String> editPart(@RequestBody EditPartRequest editPartRequest) {
        proceduresOperationsService.editPart(editPartRequest);
        return ResponseEntity.ok().body("Update Complete");
    }


}