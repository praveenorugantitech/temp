package com.ford.gpcse.external.vsem.service.impl;

import com.ford.gpcse.config.AppConfig;
import com.ford.gpcse.external.vsem.service.AuthService;
import com.ford.gpcse.model.TokenResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {
    private final AppConfig appConfig;
    private final RestClient restClient;


    @Override
    public TokenResponse fetchToken() {
        // Prepare request body
        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("grant_type", "client_credentials");
        requestBody.put("client_id", appConfig.getClientid());
        requestBody.put("client_secret", appConfig.getClientsecret());
        requestBody.put("resource", appConfig.getResource());

        try {
            return restClient.post().uri(appConfig.getOauthurl()).body(requestBody).retrieve().toEntity(TokenResponse.class).getBody();
        } catch (RestClientException e) {
            throw new RuntimeException("Error fetching token", e);
        }
    }
}
