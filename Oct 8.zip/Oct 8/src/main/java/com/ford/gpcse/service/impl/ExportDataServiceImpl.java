package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.ExportFirwareXmlRequest;
import com.ford.gpcse.entity.MicroType;
import com.ford.gpcse.entity.Part;
import com.ford.gpcse.repository.PartRepository;
import com.ford.gpcse.service.ExportDataService;
import com.ford.gpcse.util.DateFormatterUtility;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.JoinType;
import jakarta.persistence.criteria.Predicate;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayOutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ExportDataServiceImpl implements ExportDataService {
    private final PartRepository partRepository;


    @Override
    public Resource fetchFirmareXml(ExportFirwareXmlRequest exportFirwareXmlRequest) {
        if (exportFirwareXmlRequest.getExportVersion().equals("Version 3")) {
            return generateFirmwareV3Xml(exportFirwareXmlRequest);
        }
        // TODO: Need to code for other versions as well
        return null;
    }

    private Resource generateFirmwareV3Xml(ExportFirwareXmlRequest exportFirwareXmlRequest) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            // Create Document
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.newDocument();

            // Create root element
            Element rootElement = doc.createElement("ROOT");
            rootElement.setAttribute("Version", "3");
            rootElement.setAttribute("ExportedOn", DateFormatterUtility.dateTimeStringFormat(LocalDateTime.now()));
            rootElement.setAttribute("ExportedBy", exportFirwareXmlRequest.getCreateUser());
            doc.appendChild(rootElement);

            Specification<Part> spec = buildSpecification(exportFirwareXmlRequest);
            List<Part> parts = partRepository.findAll(spec);

            for (Part part : parts) {
                Element pcmElement = doc.createElement("PCM");
                rootElement.appendChild(pcmElement);

                addChildElement(doc, pcmElement, "PartNumber", part.getPartR());
                addChildElement(doc, pcmElement, "ProgramDescription", part.getPartNumX());
                addChildElement(doc, pcmElement, "CatchWord", part.getCatchWordC());
                addChildElement(doc, pcmElement, "CalibrationNumber", part.getCalibR());
                addChildElement(doc, pcmElement, "MainStrategy", part.getStratRelC());
                addChildElement(doc, pcmElement, "ApprovedDate", DateFormatterUtility.dateTimeStringFormat(part.getReldY()));
                addChildElement(doc, pcmElement, "Production", "PROT".equals(part.getReleaseUsage().getRelUsgC()) ? "N" : "Y");
                addChildElement(doc, pcmElement, "ConcernNumber", part.getConcernC());
                addChildElement(doc, pcmElement, "ReleaseEngineer", part.getEngineerCdsidC());
                addChildElement(doc, pcmElement, "ModuleType", part.getHardwarePartR());
                addChildElement(doc, pcmElement, "ChipId", part.getChipD());
                addChildElement(doc, pcmElement, "WersNotice", DateFormatterUtility.formatWersNotice(part.getWersNtcR()));
            }

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(outputStream);
            transformer.transform(source, result);

            return new ByteArrayResource(outputStream.toByteArray());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private void addChildElement(Document doc, Element parent, String name, String value) {
        Element element = doc.createElement(name);
        element.appendChild(doc.createTextNode(value != null ? value : ""));
        parent.appendChild(element);
    }

    private Specification<Part> buildSpecification(ExportFirwareXmlRequest request) {
        return (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            // Always include these base conditions
            predicates.add(criteriaBuilder.equal(root.get("archF"), "N"));
            predicates.add(criteriaBuilder.not(root.get("statC").in("NewPnRequest", "PeadEdit", "PeadComplete")));

            // Add conditions based on ExportFirwareXmlRequest
            if (request.getPartR() != null && !request.getPartR().isEmpty()) {
                predicates.add(root.get("partR").in(request.getPartR()));
            }

            if (request.getConcernC() != null && !request.getConcernC().isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("concernC"), request.getConcernC()));
            }

            if (request.getWersNtcR() != null && !request.getWersNtcR().isEmpty()) {
                predicates.add(criteriaBuilder.equal(root.get("wersNtcR"), request.getWersNtcR()));
            }

            // Join with MicroType
            Join<Part, MicroType> microTypeJoin = root.join("microType", JoinType.LEFT);
            assert query != null;
            query.multiselect(
                    root.get("partR"),
                    root.get("partNumX"),
                    root.get("catchWordC"),
                    root.get("calibR"),
                    root.get("stratRelC"),
                    root.get("reldY"),
                    root.get("concernC"),
                    root.get("engineerCdsidC"),
                    root.get("hardwarePartR"),
                    root.get("chipD"),
                    root.get("wersNtcR"),
                    root.get("stratCalibPartR"),
                    microTypeJoin.get("microTypX"),
                    root.get("releaseUsage")
            );

            // Adding order
            query.orderBy(criteriaBuilder.asc(root.get("partR")));

            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }


}
