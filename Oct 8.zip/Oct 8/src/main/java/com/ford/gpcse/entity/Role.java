package com.ford.gpcse.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCM002_ROLE")
public class Role {

    @Id
    @Column(name = "PCM002_ROLE_K", nullable = false)
    private Long roleK;

    @OneToMany(mappedBy = "role")
    private List<FirmwareRole> firmwareRoles;

    @OneToOne
    @JoinColumn(name = "PCMR17_SUPL_C", referencedColumnName = "PCMR17_SUPL_C")
    private Supplier supplier;

    @Column(name = "PCM002_ROLE_N", length = 20, nullable = false, unique = true)
    private String roleN;

    @Column(name = "PCM002_ROLE_TYP_C", length = 20, nullable = false)
    private String roleTypC;

    @Column(name = "PCM002_ARCH_F", length = 1, nullable = false)
    private String archF;

    @Column(name = "PCM002_ROLE_X", length = 350)
    private String roleX;

    @Column(name = "PCM002_CREATE_USER_C", length = 8, nullable = false)
    private String createUserC;

    @NotNull
    @CreationTimestamp
    @Column(name = "PCM002_CREATE_S", nullable = false, updatable = false)
    private LocalDateTime createS;

    @Column(name = "PCM002_LAST_UPDT_USER_C", length = 8, nullable = false)
    private String lastUpdtUserC;

    @NotNull
    @UpdateTimestamp
    @Column(name = "PCM002_LAST_UPDT_S", nullable = false)
    private LocalDateTime lastUpdtS;

}
