package com.ford.gpcse.service.impl;

import com.ford.gpcse.bo.SupplierEnrollmentRequest;
import com.ford.gpcse.exception.UnableToSendEmailNotification;
import com.ford.gpcse.external.email.service.EmailService;
import com.ford.gpcse.model.Email;
import com.ford.gpcse.service.EnrollmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EnrollmentServiceImpl implements EnrollmentService {
    private final EmailService emailService;

    @Override
    public String supplierEnrollment(SupplierEnrollmentRequest supplierEnrollmentRequest) {
        if(sendSupplierEnrollmentEmail(supplierEnrollmentRequest)) {
            return "Your request has been submitted.";
        }else{
            throw new UnableToSendEmailNotification("Your request not submitted due to SMTP failure");
        }
    }

    private boolean sendSupplierEnrollmentEmail(SupplierEnrollmentRequest supplierEnrollmentRequest) {
        String emailBody = "<HTML><HEAD></HEAD><BODY>" +
                "<P>User ID: " + supplierEnrollmentRequest.getUserId() + "</P>" +
                "<P>First Name: " + supplierEnrollmentRequest.getFirstName() + "</P>" +
                "<P>Last Name: " + supplierEnrollmentRequest.getLastName() + "</P>" +
                "<P>Email Address: " + supplierEnrollmentRequest.getEmailAddress() + "</P>" +
                "<P>Comments: " + supplierEnrollmentRequest.getComments() + "</P>" +
                "</Body></HTML>";
        Email email = Email.builder()
                .from("")// pcserel@ford.com
                .to(List.of(""))//"achopp@ford.com; icelikk2@ford.com; bnathan4@ford.com; mgunawar@ford.com;"
                .subject("Firmware User")
                .body(emailBody)
                .build();
        return emailService.sendMail(email);

    }
}
