package com.ford.gpcse.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR22_FIRMWARE_ITM")
public class FirmwareItem {

    // Primary key for this table
    @Id
    @Column(name = "PCMR22_FIRMWARE_ITM_X", nullable = false)
    private String firmwareItmX;

    // Foreign key, linking to the Firmware entity
    @Column(name = "PCMR03_FIRMWARE_K", nullable = false)
    private Long firmwareK;

    @ManyToOne(fetch = FetchType.LAZY)  // Lazy loading for performance
    @JoinColumn(name = "PCMR03_FIRMWARE_K", insertable = false, updatable = false)  // Mapping foreign key
    private Firmware firmware;

    @Column(name = "PCMR22_SORT_ORD_R")
    private Long sortOrdR;

    @Column(name = "PCMR22_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR22_CREATE_S", nullable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR22_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR22_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;
}
