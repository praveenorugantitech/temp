package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Embeddable
public class SignoffMicroTypeId {

    @Column(name = "PCMR46_SIGNOFF_TYP_C", nullable = false, length = 5)
    private String signoffTypC;

    @Column(name = "PCMR19_MICRO_TYP_C", nullable = false, length = 5)
    private Long microTypC;
}
