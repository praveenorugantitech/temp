package com.ford.gpcse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder
@Table(name = "WPCMR15_REL_TYP")
public class ReleaseType {

    @Id
    @Column(name = "PCMR15_REL_TYP_C", length = 5)
    private String relTypC;

    @Column(name = "PCMR15_REL_TYP_X", length = 50)
    private String relTypX;

    @Column(name = "PCMR15_ARCH_F", length = 1)
    private String archF;

    @Column(name = "PCMR15_SORT_ORD_R", precision = 4, scale = 0)
    private BigDecimal sortOrdR;


    @Column(name = "PCMR15_CREATE_USER_C", nullable = false)
    private String createUserC;

    @Column(name = "PCMR15_CREATE_S", nullable = false)
    @CreationTimestamp
    private LocalDateTime createS;

    @Column(name = "PCMR15_LAST_UPDT_USER_C", nullable = false)
    private String lastUpdtUserC;

    @Column(name = "PCMR15_LAST_UPDT_S", nullable = false)
    @UpdateTimestamp
    private LocalDateTime lastUpdtS;
}
